# === Ganti Renderer ke SKIAGL ===
settings put global rendering_type skiagl
setprop debug.composition.type skiagl
setprop debug.hwui.default_renderer skiagl
setprop debug.hwui.renderer skiagl
setprop debug.angle.backend opengl
setprop debug.renderengine.vulkan 0
setprop debug.renderengine.backend skiagl
setprop debug.hwui.force_gpu_for_2d true
setprop debug.hwui.force_gpu_for_3d false
setprop debug.hwui.force_gpu_for_4d false
setprop debug.sf.multithreaded_present true
setprop debug.renderthread.skia.reduceopstasksplitting true
setprop debug.hw3d.force 1
settings put system Hardware.Renderer 1
settings put system HardwareAccelerated true
settings put system HardwareRenderer.Accelerated 1
settings put system HardwareRenderer.FrameRenderRequest 999
settings put system HardwareRenderer.CodecImgBits 10000
settings put system HardwareBuffer 32
settings put system gpu_mode host
settings put system gpu_option_mode host
settings put system game.accelerate.hw 1
setprop debug.renderthread.reduceopstasksplitting true
setprop debug.renderer.process compound
setprop debug.qsg_renderer 1
setprop debug.rs.max-threads 8
setprop debug.rs.min-threads 8
setprop debug.rs.max-freq 3800000
setprop debug.rs.min-freq 3800000
setprop debug.rs.min-perf_percent 100
setprop debug.rs.max-temp_tolerance 90
setprop debug.performance.accoustic.force true
setprop debug.javafx.animation.fullspeed true
setprop debug.javafx.animation.framerate 120
setprop debug.redroid.fps 120
setprop debug.systemuicompilerfilter speed
setprop debug.sf.scroll_boost_refreshrate 1
setprop debug.sf.default_rate 0
settings put global enable_hw_accelerated_windows 1
settings put global battery_saver_constants null
setprop debug.rs.animation.framerate 120
setprop debug.sf.animation.framerate 120
settings put global gpu_render_buffer 1
settings put global hardware_accelerated_rendering_enabled 1
settings put global gpu_overdraw_show_count 4
settings put global gpu_debug_layers_enable 1
setprop debug.rs.animation.fullspeed true
setprop debug.app.performance_restricted false
# HWUI Optimized
setprop debug.hwui.disable_draw_defer true
setprop debug.hwui.use_hint_manager true
setprop debug.hwui.use_gpu_pixel_buffers true
setprop debug.hwui.render_dirty_regions true
setprop debug.hwui.skip_empty_damage true
setprop debug.hwui.use_buffer_age true
setprop debug.hwui.use_partial_updates true
setprop debug.hwui.app_memory_policy balanced
#SurfaceFlinger Optimize Skia
setprop debug.sf.enable_adpf_cpu_hint true
setprop debug.sf.auto_latch_unsignaled 1
setprop debug.sf.luma_sampling 1
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.enable_advanced_sf_phase_offset 1
setprop debug.sf.drop_missed_frames 1
setprop debug.sf.multithreaded_present 1
setprop debug.sf.use_frame_rate_priority 1
setprop debug.sf.predict_hwc_composition_strategy 1
setprop debug.sf.disable_backpressure 1
setprop setprop debug.sf.enable_gl_backpressure 0
setprop debug.sf.set_idle_timer_ms 0
setprop debug.sf.kernel_idle_timer_update_overlay 0
# XR Rendering pakai OpenGL
setprop debug.xr.graphicsPlugin OpenGLES
setprop debug.xr.graphicsPlugin.OpenGLES 1
setprop debug.xr.graphicsPlugin.Vulkan 0
setprop debug.renderengine_blender true
setprop debug.xr.blendMode Opaque
# === Optimalisasi HWUI & RenderEngine untuk SKIAGL ===
setprop debug.hwui.profile true
setprop debug.qsg_renderer 1
setprop debug.force-opengl 1
setprop debug.renderengine.capture_skia_ms 0
setprop debug.renderengine.capture_filename 0
setprop debug.hwui.initialize_gl_always true
setprop debug.hwui.skip_eglmanager_telemetry true
setprop debug.hwui.drawing_enabled true
setprop debug.hwui.show_layer_grid 0
setprop debug.hwui.show_layer_bounds 0
setprop debug.hwui.show_draw_order 0
setprop debug.hwui.show_draw_calls 0
setprop debug.hwui.use_d2d 1
setprop debug.renderer.process compound
setprop debug.renderer.process_compound false
setprop debug.sf.log_expensive_rendering true
setprop debug.threadedOpt 1
setprop debug.syncopts 0
setprop debug.sf.set_binder_thread_rt 1
setprop debug.sf.multithreaded_present 1
setprop debug.hwui.disable_scissor_opt false
setprop debug.hwui.level 2
setprop debug.hwui.render_priority 1
setprop debug.hwui.render_thread_disable_fence false
setprop debug.hwui.render_ahead true
setprop debug.hwui.render_thread_count 2
setprop debug.skia.render_thread_priority true
setprop debug.skia.num_render_threads 4
setprop debug.skia.threaded_mode true
# Tambahan: Debug Layer OpenGL
settings put global enable_gpu_debug_layers 1
settings put global gpu_debug_layers GL_KHR_debug
# === Akselerasi HWUI / OpenGL ===
setprop debug.egl.hw 1
setprop debug.sf.hw 1
settings put system persist.sys.use_dithering 1
settings put system hw.accelerated 1
settings put system video.accelerated 1
settings put system game.accelerated 1
settings put system ui.accelerated 1
settings put system enable_hardware_accelerated true
settings put system enable_optimize_refresh_rate true
settings put system service.lgospd.enable 0
settings put system service.pcsync.enable 0
settings put system dalvik.hyperthreading true
settings put system dalvik.multithread true
# === Performance Boost untuk OpenGL ===
setprop debug.performance.tuning 1
settings put system config.hw_quickpoweron true
# === Device Config: Nonaktifkan Vulkan, fokus SKIAGL ===
device_config put core_graphics com.android.graphics.surfaceflinger.flags.vulkan_renderengine false
device_config delete core_graphics com.android.graphics.libvulkan.flags.swapchain_mutable_format_ext
device_config put core_graphics com.android.xr.graphicsPlugin OpenGLES
device_config delete core_graphics com.android.xr.graphicsPlugin.Vulkan
device_config delete staged core_graphics*com.android.graphics.surfaceflinger.flags.vulkan_renderengine
# === Simulasi Thread Prioritas & SkiaGL ===
settings put global skia_rendering skiagl
settings put global skia_renderer_level 2
settings put global render_thread_count 2
settings put global skia_threaded_mode true
settings put global hwui_thread_priority 1
settings put global enable_vulkan_renderengine false
) > /dev/null 2>&1