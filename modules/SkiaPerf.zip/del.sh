(
# === Balikin Renderer ke default (biar system tentuin) ===
# HWUI Optimized
setprop debug.hwui.disable_draw_defer ""
setprop debug.hwui.use_hint_manager ""
setprop debug.hwui.use_gpu_pixel_buffers ""
setprop debug.hwui.render_dirty_regions ""
setprop debug.hwui.skip_empty_damage ""
setprop debug.hwui.use_buffer_age ""
setprop debug.hwui.use_partial_updates ""
setprop debug.hwui.app_memory_policy ""
#SurfaceFlinger Optimize Skia
setprop debug.sf.enable_adpf_cpu_hint ""
setprop debug.sf.auto_latch_unsignaled ""
setprop debug.sf.luma_sampling ""
setprop debug.sf.use_phase_offsets_as_durations ""
setprop debug.sf.enable_advanced_sf_phase_offset ""
setprop debug.sf.drop_missed_frames ""
setprop debug.sf.multithreaded_present ""
setprop debug.sf.use_frame_rate_priority ""
setprop debug.sf.predict_hwc_composition_strategy ""
setprop debug.sf.disable_backpressure ""
setprop setprop debug.sf.enable_gl_backpressure ""
setprop debug.sf.set_idle_timer_ms ""
setprop debug.sf.kernel_idle_timer_update_overlay ""
setprop debug.composition.type ""
setprop debug.hwui.default_renderer ""
setprop debug.hwui.renderer ""
setprop debug.angle.backend ""
setprop debug.renderengine.vulkan ""
setprop debug.renderengine.backend ""
setprop debug.hwui.force_gpu_for_2d ""
setprop debug.hwui.force_gpu_for_3d ""
setprop debug.hwui.force_gpu_for_4d ""
setprop debug.sf.multithreaded_present ""
setprop debug.renderthread.skia.reduceopstasksplitting ""
setprop debug.hw3d.force 
settings delete system Hardware.Renderer 
settings delete system HardwareAccelerated 
settings delete system HardwareRenderer.Accelerated 
settings delete system HardwareRenderer.FrameRenderRequest 
settings delete system HardwareRenderer.CodecImgBits 
settings delete system HardwareBuffer 
settings delete system gpu_mode 
settings delete system gpu_option_mode 
settings delete system game.accelerate.hw 
setprop debug.renderthread.reduceopstasksplitting ""
setprop debug.renderer.process ""
setprop debug.qsg_renderer ""
setprop debug.rs.max-threads ""
setprop debug.rs.min-threads ""
setprop debug.rs.max-freq ""
setprop debug.rs.min-freq ""
setprop debug.rs.min-perf_percent ""
setprop debug.rs.max-temp_tolerance ""
setprop debug.performance.accoustic.force ""
setprop debug.javafx.animation.fullspeed ""
setprop debug.javafx.animation.framerate ""
setprop debug.redroid.fps ""
setprop debug.systemuicompilerfilter ""
setprop debug.sf.scroll_boost_refreshrate ""
setprop debug.sf.default_rate ""
settings delete global enable_hw_accelerated_windows 
settings delete global battery_saver_constants 
setprop debug.rs.animation.framerate ""
setprop debug.sf.animation.framerate ""
settings delete global gpu_render_buffer 
settings delete global hardware_accelerated_rendering_enabled 
settings delete global gpu_overdraw_show_count ""
settings delete global gpu_debug_layers_enable 
setprop debug.rs.animation.fullspeed ""
setprop debug.app.performance_restricted ""
# XR Rendering default
setprop debug.xr.graphicsPlugin ""
setprop debug.xr.graphicsPlugin.OpenGLES ""
setprop debug.xr.graphicsPlugin.Vulkan ""
setprop debug.renderengine_blender ""
setprop debug.xr.blendMode ""
# HWUI & RenderEngine default
setprop debug.hwui.profile ""
setprop debug.egl.profiler ""
setprop debug.qsg_renderer ""
setprop debug.force-opengl ""
setprop debug.renderengine.capture_skia_ms ""
setprop debug.renderengine.capture_filename ""
setprop debug.hwui.initialize_gl_always ""
setprop debug.hwui.skip_eglmanager_telemetry ""
setprop debug.hwui.drawing_enabled ""
setprop debug.hwui.show_layer_grid ""
setprop debug.hwui.show_layer_bounds ""
setprop debug.hwui.show_draw_order ""
setprop debug.hwui.show_draw_calls ""
setprop debug.hwui.use_d2d ""
setprop debug.renderer.process ""
setprop debug.renderer.process_compound ""
setprop debug.sf.log_expensive_rendering ""
setprop debug.threadedOpt ""
setprop debug.syncopts ""
setprop debug.sf.set_binder_thread_rt ""
setprop debug.sf.multithreaded_present ""
setprop debug.hwui.disable_scissor_opt ""
setprop debug.hwui.level ""
setprop debug.hwui.render_priority ""
setprop debug.hwui.render_thread_disable_fence ""
setprop debug.hwui.render_ahead ""
setprop debug.hwui.render_thread_count ""
setprop debug.skia.render_thread_priority ""
setprop debug.skia.num_render_threads ""
setprop debug.skia.threaded_mode ""
# === Hapus settings ===
settings delete global rendering_type
settings delete system thread_priority
settings delete secure thread_priority
settings delete global enable_gpu_debug_layers
settings delete global gpu_debug_layers
settings delete system persist.sys.use_dithering
settings delete system hw.accelerated
settings delete system video.accelerated
settings delete system game.accelerated
settings delete system ui.accelerated
settings delete system enable_hardware_accelerated
settings delete system enable_optimize_refresh_rate
settings delete system service.lgospd.enable
settings delete system service.pcsync.enable
settings delete system dalvik.hyperthreading
settings delete system dalvik.multithread
settings delete system config.hw_quickpoweron
settings delete global skia_rendering
settings delete global skia_renderer_level
settings delete global render_thread_count
settings delete global skia_threaded_mode
settings delete global hwui_thread_priority
settings delete global enable_vulkan_renderengine
# === Device Config default (aktifkan kembali Vulkan) ===
device_config delete core_graphics com.android.graphics.surfaceflinger.flags.vulkan_renderengine
device_config delete core_graphics com.android.graphics.libvulkan.flags.swapchain_mutable_format_ext
device_config delete core_graphics com.android.xr.graphicsPlugin
device_config delete staged core_graphics*com.android.graphics.surfaceflinger.flags.vulkan_renderengine
) > /dev/null 2>&1