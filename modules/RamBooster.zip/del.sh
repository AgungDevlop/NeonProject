#!/bin/bash

# Ram Booster Uninstall - Reset to Default by Agung Developer (Non-Root Version)

# Save uninstallation date
date '+%Y-%m-%d %H:%M:%S' > /data/local/tmp/ram_booster_uninstall_date 2>/dev/null || echo "Unable to save uninstallation date"

INSTALL_DATE=$(cat /data/local/tmp/ram_booster_uninstall_date 2>/dev/null || echo "Unknown")

# Display device information
echo "---------------------------------------------"
echo "|         DEVICE AND HARDWARE INFO          |"
echo "---------------------------------------------"
echo "| Device   : $(getprop ro.product.manufacturer 2>/dev/null || echo 'Unknown') $(getprop ro.product.model 2>/dev/null || echo 'Unknown') |"
echo "| CPU      : $(getprop ro.board.platform 2>/dev/null || echo 'Unknown') |"
echo "| GPU      : $(getprop ro.hardware 2>/dev/null || echo 'Unknown') |"
echo "| Android  : $(getprop ro.build.version.release 2>/dev/null || echo 'Unknown') |"
echo "| Install  : $INSTALL_DATE |"
echo "| Kernel   : $(uname -r 2>/dev/null || echo 'Unknown') |"
echo "| Build    : $(getprop ro.build.display.id 2>/dev/null || echo 'Unknown') |"
echo "| Root     : No (Non-root mode) |"
echo "| SELinux  : $(getenforce 2>/dev/null || echo 'Unknown') |"
echo "---------------------------------------------"

echo ""
echo "=== WELCOME TO RAM BOOSTER UNINSTALL ==="
echo ""
sleep 0.5

# Check if required commands are available
if ! command -v settings >/dev/null 2>&1; then
    echo "Error: Required command 'settings' not found. This script requires ADB with proper permissions."
    exit 1
fi

# UNINSTALLATION PROCESS
echo "Starting system restoration..."
sleep 1
echo "Resetting system settings to default..."
sleep 1

# Reset settings applied in the installation script
{
    settings put global animator_duration_scale 1.0 2>/dev/null || echo "Warning: Unable to reset animator_duration_scale"
    settings put global transition_animation_scale 1.0 2>/dev/null || echo "Warning: Unable to reset transition_animation_scale"
    settings put global window_animation_scale 1.0 2>/dev/null || echo "Warning: Unable to reset window_animation_scale"
    settings put global wifi_scan_always_enabled 1 2>/dev/null || echo "Warning: Unable to reset wifi_scan_always_enabled"
    settings put secure adaptive_sleep 1 2>/dev/null || echo "Warning: Unable to reset adaptive_sleep"
    settings put secure screensaver_enabled 1 2>/dev/null || echo "Warning: Unable to reset screensaver_enabled"
    settings delete global activity_manager_constants 2>/dev/null || echo "Warning: Unable to reset activity_manager_constants"
    settings delete global low_ram 2>/dev/null || echo "Warning: Unable to reset low_ram"
} &

# Clean up temporary files
echo "Removing temporary files..."
rm -f /data/local/tmp/ram_booster 2>/dev/null
rm -f /data/local/tmp/ram_booster_install_date 2>/dev/null
rm -f /data/local/tmp/ram_booster_uninstall_date 2>/dev/null

echo "Ram Booster has been removed & settings restored to default."
sleep 0.5

echo ""
echo "Resetting Ram Booster"
echo ""
sleep 0.5
echo ""
echo "ALL SETTINGS RESTORED"
echo ""
sleep 0.5
echo ""
echo "REMOVING ALL TWEAKS"
echo ""
sleep 0.5
echo ""
echo "AGUNG DEVELOPER"
echo ""
sleep 0.5
echo ""
echo "THANKS FOR USING RAM BOOSTER"
echo ""
sleep 0.5
echo ""
echo "=== THANKS FOR USING MODULE ==="
echo ""

# Post notification (if supported)
cmd notification post -S bigtext -t 'RAM BOOSTER' 'Uninstall' 'Successfully Removed.' 2>/dev/null &