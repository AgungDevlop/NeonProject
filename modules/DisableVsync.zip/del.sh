service call SurfaceFlinger 1035 i32 1
pm revoke --user 0 com.refreshrate.arc android.permission.POST_NOTIFICATIONS
pm revoke --user 0 com.refreshrate.arc moe.shizuku.manager.permission.API_V23
pm revoke --user 0 --all-permissions com.refreshrate.arc
# Setprop Tracing
# 802922
cmd window tracing size 802922
setprop debug.vendor.perf.smart_touch.trace 1
setprop debug.atrace.tags.enableflags 802922
setprop debug.sf.trace_hint_sessions true
setprop debug.surfacetrace.enabled 1
setprop debug.renderengine.skia_use_perfetto_track_events true
setprop debug.renderengine.skia_tracing_enabled true
setprop debug.hwui.skia_atrace_enabled true
setprop debug.hwui.skia_tracing_enabled true
setprop debug.hwui.skia_use_perfetto_track_events true
setprop debug.perfetto.sdk_sysprop_guard_generation 1
setprop debug.egl.trace 1
setprop debug.egl.traceGpuCompletion 1
setprop debug.onetrace.native.tag 1
setprop debug.onetrace.tag 1
setprop debug.onetrace.version 1
setprop debug.oplus.mtrace 1
setprop debug.sf.oplus_display_trace.enable 1
setprop debug.sf.oplus_display_trace.size 802922
setprop debug.oplus.systrace_enhance true
setprop debug.atrace.user_initiated 1
setprop debug.atrace.prefer_sdk 1
setprop debug.atrace.app_number 1
setprop debug.sf.enable_transaction_tracing 1
setprop debug.sf.layer_history_trace 1
setprop debug.tracing.desktop_mode_visible_tasks 1
setprop debug.tracing.block_touch_buffer 1
setprop debug_tracing_desktop_mode_visible_tasks_prop 1
setprop debug.hwui.trace_gpu_resources true
setprop debug.perfmond.atrace 1
setprop persist.sys.oplus_trace 1
setprop sys.oplus.ood.onetrace.diag true
setprop sys.trace.traced_started 1
setprop sys.wifitracing.started 1
setprop sys.systrace.perfetto.tracing 1

# Vsync Tracing
setprop debug.sf.enable_vsync_immed 1
setprop debug.sf.vsync_trace_detailed_info 1
setprop debug.sf.vst_trace 1
setprop debug.sf.vsr_trace 1
setprop debug.sf.vsp_trace 1
setprop debug.choreographer.vsync true
setprop debug.hwui.disable_vsync false
setprop debug.cpurend.vsync true
setprop debug.gpurend.vsync true
setprop debug.hwui.force_no_vsync false
setprop debug.hwui.skip_vsync false
setprop debug.hwc.fakevsync 1
setprop debug.hwc.logvsync 1
setprop debug.hwc.force_gpu_vsync true
setprop debug.sf.hwc_hotplug_error_via_neg_vsync 1
setprop debug.sf.hwc_hdcp_via_neg_vsync 1
setprop debug.sf.no_hw_vsync 0
setprop debug.sf.vsync_reactor true
setprop debug.sf.vsync_reactor_ignore_present_fences 1
setprop debug.sf.show_predicted_vsync true
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 1
setprop persist.sys.vsync_optimization_enable true
setprop persist.sys.hwui.dyn_vsync 1
setprop persist.sys.vsync 1
setprop persist.sys.fake_vsync_support true
setprop sys.surfaceflinger.aggressivevsync true

# Device Config Vsync
device_config put core_graphics com.android.graphics.surfaceflinger.flags.allow_n_vsyncs_in_targeter true
device_config put core_graphics com.android.graphics.surfaceflinger.flags.deprecate_vsync_sf true
device_config put display_manager com.android.server.display.feature.flags.enable_vsync_low_light_vote true
device_config put display_manager com.android.server.display.feature.flags.enable_vsync_low_power_vote true
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.allow_n_vsyncs_in_targeter true
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.deprecate_vsync_sf true
device_config put staged display_manager*com.android.server.display.feature.flags.enable_vsync_low_light_vote true
device_config put staged display_manager*com.android.server.display.feature.flags.enable_vsync_low_power_vote true

# Perfetto
device_config put media_audio com.android.media.audioserver.fix_concurrent_playback_behavior_with_bit_perfect_client true
device_config put runtime_native_boot iorap_perfetto_enable true
device_config put system_performance android.os.perfetto_sdk_tracing true
device_config put windowing_tools android.tracing.perfetto_ime true
device_config put windowing_tools android.tracing.perfetto_ime_tracing true
device_config put windowing_tools android.tracing.perfetto_protolog_tracing true
device_config put windowing_tools android.tracing.perfetto_transition_tracing true
device_config put windowing_tools android.tracing.perfetto_view_capture_tracing true

# Trace
device_config put backstage_power com.android.server.am.trace_receiver_registration true
device_config put core_graphics com.android.graphics.libgui.flags.trace_frame_rate_override true
device_config put core_graphics com.android.graphics.surfaceflinger.flags.add_sf_skipped_frames_to_trace false
device_config put interaction_jank_monitor trace_threshold_frame_time_millis 1
device_config put interaction_jank_monitor trace_threshold_missed_frames 1
device_config put latency_tracker action_show_voice_interaction_trace_threshold 1
device_config put systemui com.android.server.notification.trace_cancel_events true

# Tracing
device_config put input com.android.input.flags.enable_input_event_tracing true
device_config put sensors com.android.hardware.libsensor.flags.sensor_event_queue_report_sensor_usage_in_tracing true
device_config put surface_flinger_native_boot SkiaTracingFeature__use_skia_tracing true
device_config put systemui com.android.systemui.coroutine_tracing true
device_config put systemui com.android.systemui.enable_layout_tracing true
device_config put systemui com.android.systemui.enable_view_capture_tracing true

setprop debug.tracing.battery_status 3
setprop debug.tracing.device_state 0:DEFAULT
setprop debug.tracing.mcc 510
setprop debug.tracing.mnc 1
setprop debug.tracing.plug_type 1
setprop debug.tracing.screen_brightness 0.23275635
setprop debug.vendor.perf.smart_touch.trace ""
setprop debug.atrace.tags.enableflags ""
setprop debug.sf.trace_hint_sessions ""
setprop debug.surfacetrace.enabled ""
setprop debug.renderengine.skia_use_perfetto_track_events ""
setprop debug.renderengine.skia_tracing_enabled ""
setprop debug.hwui.skia_atrace_enabled ""
setprop debug.hwui.skia_tracing_enabled ""
setprop debug.hwui.skia_use_perfetto_track_events ""
setprop debug.perfetto.sdk_sysprop_guard_generation 0
setprop debug.egl.trace ""
setprop debug.egl.traceGpuCompletion ""
setprop debug.onetrace.native.tag ""
setprop debug.onetrace.tag ""
setprop debug.onetrace.version ""
setprop debug.oplus.mtrace ""
setprop debug.sf.oplus_display_trace.enable ""
setprop debug.sf.oplus_display_trace.size ""
setprop debug.oplus.systrace_enhance ""
setprop debug.atrace.user_initiated ""
setprop debug.atrace.prefer_sdk ""
setprop debug.atrace.app_number ""
setprop debug.sf.enable_transaction_tracing ""
setprop debug.sf.layer_history_trace ""
setprop debug.tracing.desktop_mode_visible_tasks ""
setprop debug.tracing.block_touch_buffer ""
setprop debug_tracing_desktop_mode_visible_tasks_prop ""
setprop debug.hwui.trace_gpu_resources ""
setprop debug.perfmond.atrace ""
setprop persist.sys.oplus_trace ""
setprop sys.oplus.ood.onetrace.diag ""
setprop sys.trace.traced_started ""
setprop sys.wifitracing.started ""
setprop sys.systrace.perfetto.tracing ""

# Vsync Tracing
setprop debug.sf.enable_vsync_immed ""
setprop debug.sf.vsync_trace_detailed_info ""
setprop debug.sf.vst_trace ""
setprop debug.sf.vsr_trace ""
setprop debug.sf.vsp_trace ""
setprop debug.choreographer.vsync ""
setprop debug.hwui.disable_vsync ""
setprop debug.cpurend.vsync ""
setprop debug.gpurend.vsync ""
setprop debug.hwui.force_no_vsync ""
setprop debug.hwui.skip_vsync ""
setprop debug.hwc.fakevsync ""
setprop debug.hwc.logvsync ""
setprop debug.hwc.force_gpu_vsync ""
setprop debug.sf.hwc_hotplug_error_via_neg_vsync ""
setprop debug.sf.hwc_hdcp_via_neg_vsync ""
setprop debug.sf.no_hw_vsync ""
setprop debug.sf.vsync_reactor ""
setprop debug.sf.vsync_reactor_ignore_present_fences ""
setprop debug.sf.show_predicted_vsync ""
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns ""
setprop persist.sys.vsync_optimization_enable ""
setprop persist.sys.hwui.dyn_vsync ""
setprop persist.sys.vsync ""
setprop persist.sys.fake_vsync_support ""
setprop sys.surfaceflinger.aggressivevsync ""

# Device Config Vsync
device_config delete core_graphics com.android.graphics.surfaceflinger.flags.allow_n_vsyncs_in_targeter 
device_config delete core_graphics com.android.graphics.surfaceflinger.flags.deprecate_vsync_sf 
device_config delete display_manager com.android.server.display.feature.flags.enable_vsync_low_light_vote 
device_config delete display_manager com.android.server.display.feature.flags.enable_vsync_low_power_vote 
device_config delete staged core_graphics*com.android.graphics.surfaceflinger.flags.allow_n_vsyncs_in_targeter 
device_config delete staged core_graphics*com.android.graphics.surfaceflinger.flags.deprecate_vsync_sf 
device_config delete staged display_manager*com.android.server.display.feature.flags.enable_vsync_low_light_vote 
device_config delete staged display_manager*com.android.server.display.feature.flags.enable_vsync_low_power_vote 

# Perfetto
device_config delete media_audio com.android.media.audioserver.fix_concurrent_playback_behavior_with_bit_perfect_client 
device_config delete runtime_native_boot iorap_perfetto_enable 
device_config delete system_performance android.os.perfetto_sdk_tracing 
device_config delete windowing_tools android.tracing.perfetto_ime 
device_config delete windowing_tools android.tracing.perfetto_ime_tracing 
device_config delete windowing_tools android.tracing.perfetto_protolog_tracing 
device_config delete windowing_tools android.tracing.perfetto_transition_tracing 
device_config delete windowing_tools android.tracing.perfetto_view_capture_tracing 

# Trace
device_config delete backstage_power com.android.server.am.trace_receiver_registration 
device_config delete core_graphics com.android.graphics.libgui.flags.trace_frame_rate_override 
device_config delete core_graphics com.android.graphics.surfaceflinger.flags.add_sf_skipped_frames_to_trace 
device_config delete interaction_jank_monitor trace_threshold_frame_time_millis 
device_config delete interaction_jank_monitor trace_threshold_missed_frames 
device_config delete latency_tracker action_show_voice_interaction_trace_threshold 
device_config delete systemui com.android.server.notification.trace_cancel_events 

# Tracing
device_config delete input com.android.input.flags.enable_input_event_tracing 
device_config delete sensors com.android.hardware.libsensor.flags.sensor_event_queue_report_sensor_usage_in_tracing 
device_config delete surface_flinger_native_boot SkiaTracingFeature__use_skia_tracing 
device_config delete systemui com.android.systemui.coroutine_tracing 
device_config delete systemui com.android.systemui.enable_layout_tracing 
device_config delete systemui com.android.systemui.enable_view_capture_tracing 
echo "Done"
pkill -f disable-vsync.sh
pkill -f /data/local/tmp/disable-vsync.sh
rm -f nohup.out

TWEAK="/data/local/tmp/disable-vsync.sh"

if [ -f "$TWEAK" ]; then
    [ -f "$TWEAK" ] && rm -f "$TWEAK"
    
    echo "✅ Berhasil menghapus file tweak"
    cmd notification post -S bigtext -t '🗑️ @modulegaming6969fps' 'File Dihapus' "Tweak berhasil dihapus dari /data/local/tmp" > /dev/null 2>&1
    am start -a android.intent.action.MAIN \
        -e toasttext "Tweak berhasil dihapus dari /data/local/tmp" \
        -n bellavita.toast/.MainActivity > /dev/null 2>&1
else
    echo "❌ File tweak tidak ditemukan"
    cmd notification post -S bigtext -t '⚠️ @modulegaming6969fps' 'Gagal Menghapus' "File tweak tidak ditemukan di /data/local/tmp" > /dev/null 2>&1
    am start -a android.intent.action.MAIN \
        -e toasttext "File tweak tidak ditemukan di /data/local/tmp" \
        -n bellavita.toast/.MainActivity > /dev/null 2>&1
fi
cmd notification post -S bigtext -t '🔥@modulegaming6969fps' 'Subscribe' "Berhasil Di Uninstall" > /dev/null 2>&1
am start -a android.intent.action.MAIN \
  -e toasttext "🔥Berhasil Di Uninstall" \
  -n bellavita.toast/.MainActivity > /dev/null 2>&1