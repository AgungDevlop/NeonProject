service call SurfaceFlinger 1035 i32 0
pm grant --user 0 com.refreshrate.arc android.permission.POST_NOTIFICATIONS
pm grant --user 0 com.refreshrate.arc moe.shizuku.manager.permission.API_V23
pm grant --user 0 --all-permissions com.refreshrate.arc
# Pastikan direktori TMP ada
mkdir -p /data/local/tmp

# Isi skrip yang ingin ditulis ke disable-vsync.sh
cat << 'EOF' > /data/local/tmp/disable-vsync.sh
#!/system/bin/sh

while true; do
    echo "✅ Menjalankan Vsync"
    am start start-in-vsync
    cmd activity start-in-vsync
    cmd notification post -S bigtext -t '🔥@modulegaming6969fps' 'Subscribe' "Berhasil Menyingkronkan Vsync" > /dev/null 2>&1
    am start -a android.intent.action.MAIN \
      -e toasttext "🔥Berhasil Menyingkronkan Vsync" \
      -n bellavita.toast/.MainActivity > /dev/null 2>&1
    sleep 900
done &
EOF

# Buat file dapat dieksekusi
chmod +x /data/local/tmp/disable-vsync.sh
# Jalankan di background
nohup sh /data/local/tmp/disable-vsync.sh > /dev/null 2>&1 &
# Setprop Tracing
# 802922
cmd window tracing size 0
setprop debug.tracing.battery_status 0
setprop debug.tracing.device_state 0:IDLE
setprop debug.tracing.mcc 0
setprop debug.tracing.mnc 0
setprop debug.tracing.plug_type 0
setprop debug.tracing.screen_brightness 0
setprop debug.vendor.perf.smart_touch.trace 0
setprop debug.atrace.tags.enableflags 0
setprop debug.sf.trace_hint_sessions false
setprop debug.surfacetrace.enabled 0
setprop debug.renderengine.skia_use_perfetto_track_events false
setprop debug.renderengine.skia_tracing_enabled false
setprop debug.hwui.skia_atrace_enabled false
setprop debug.hwui.skia_tracing_enabled false
setprop debug.hwui.skia_use_perfetto_track_events false
setprop debug.perfetto.sdk_sysprop_guard_generation 0
setprop debug.egl.trace 0
setprop debug.egl.traceGpuCompletion 0
setprop debug.onetrace.native.tag 0
setprop debug.onetrace.tag 0
setprop debug.onetrace.version 0
setprop debug.oplus.mtrace 0
setprop debug.sf.oplus_display_trace.enable 0
setprop debug.sf.oplus_display_trace.size 0
setprop debug.oplus.systrace_enhance false
setprop debug.atrace.user_initiated 0
setprop debug.atrace.prefer_sdk 0
setprop debug.atrace.app_number 0
setprop debug.sf.enable_transaction_tracing 0
setprop debug.sf.layer_history_trace 0
setprop debug.tracing.desktop_mode_visible_tasks 0
setprop debug.tracing.block_touch_buffer 0
setprop debug_tracing_desktop_mode_visible_tasks_prop 0
setprop debug.hwui.trace_gpu_resources false
setprop debug.perfmond.atrace 0
setprop persist.sys.oplus_trace 0
setprop sys.oplus.ood.onetrace.diag false
setprop sys.trace.traced_started 0
setprop sys.wifitracing.started 0
setprop sys.systrace.perfetto.tracing 0

# Vsync Tracing
setprop debug.sf.enable_vsync_immed 0
setprop debug.sf.vsync_trace_detailed_info 0
setprop debug.sf.vst_trace 0
setprop debug.sf.vsr_trace 0
setprop debug.sf.vsp_trace 0
setprop debug.choreographer.vsync false
setprop debug.hwui.disable_vsync true
setprop debug.cpurend.vsync false
setprop debug.gpurend.vsync false
setprop debug.hwui.force_no_vsync true
setprop debug.hwui.skip_vsync true
setprop debug.hwc.fakevsync 0
setprop debug.hwc.logvsync 0
setprop debug.hwc.force_gpu_vsync false
setprop debug.sf.hwc_hotplug_error_via_neg_vsync 0
setprop debug.sf.hwc_hdcp_via_neg_vsync 0
setprop debug.sf.no_hw_vsync 1
setprop debug.sf.vsync_reactor false
setprop debug.sf.vsync_reactor_ignore_present_fences 0
setprop debug.sf.show_predicted_vsync false
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 0
setprop persist.sys.vsync_optimization_enable false
setprop persist.sys.hwui.dyn_vsync 0
setprop persist.sys.vsync 0
setprop persist.sys.fake_vsync_support false
setprop sys.surfaceflinger.aggressivevsync false

# Device Config Vsync
device_config put core_graphics com.android.graphics.surfaceflinger.flags.allow_n_vsyncs_in_targeter false
device_config put core_graphics com.android.graphics.surfaceflinger.flags.deprecate_vsync_sf false
device_config put display_manager com.android.server.display.feature.flags.enable_vsync_low_light_vote false
device_config put display_manager com.android.server.display.feature.flags.enable_vsync_low_power_vote false
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.allow_n_vsyncs_in_targeter false
device_config put staged core_graphics*com.android.graphics.surfaceflinger.flags.deprecate_vsync_sf false
device_config put staged display_manager*com.android.server.display.feature.flags.enable_vsync_low_light_vote false
device_config put staged display_manager*com.android.server.display.feature.flags.enable_vsync_low_power_vote false

# Perfetto
device_config put media_audio com.android.media.audioserver.fix_concurrent_playback_behavior_with_bit_perfect_client false
device_config put runtime_native_boot iorap_perfetto_enable false
device_config put system_performance android.os.perfetto_sdk_tracing false
device_config put windowing_tools android.tracing.perfetto_ime false
device_config put windowing_tools android.tracing.perfetto_ime_tracing false
device_config put windowing_tools android.tracing.perfetto_protolog_tracing false
device_config put windowing_tools android.tracing.perfetto_transition_tracing false
device_config put windowing_tools android.tracing.perfetto_view_capture_tracing false

# Trace
device_config put backstage_power com.android.server.am.trace_receiver_registration false
device_config put core_graphics com.android.graphics.libgui.flags.trace_frame_rate_override false
device_config put core_graphics com.android.graphics.surfaceflinger.flags.add_sf_skipped_frames_to_trace true
device_config put interaction_jank_monitor trace_threshold_frame_time_millis -1
device_config put interaction_jank_monitor trace_threshold_missed_frames -1
device_config put latency_tracker action_show_voice_interaction_trace_threshold -1
device_config put systemui com.android.server.notification.trace_cancel_events false

# Tracing
device_config put input com.android.input.flags.enable_input_event_tracing false
device_config put sensors com.android.hardware.libsensor.flags.sensor_event_queue_report_sensor_usage_in_tracing false
device_config put surface_flinger_native_boot SkiaTracingFeature__use_skia_tracing false
device_config put systemui com.android.systemui.coroutine_tracing false
device_config put systemui com.android.systemui.enable_layout_tracing false
device_config put systemui com.android.systemui.enable_view_capture_tracing false
echo "Done"
cmd notification post -S bigtext -t '🔥@modulegaming6969fps' 'Subscribe' "Berhasil Di Install" > /dev/null 2>&1
am start -a android.intent.action.MAIN \
  -e toasttext "🔥Berhasil Di Install" \
  -n bellavita.toast/.MainActivity > /dev/null 2>&1
am start -a android.intent.action.MAIN \
    -e open-app "Your Lock Refresh Rate" \
    -n com.refreshrate.arc/.MainActivity