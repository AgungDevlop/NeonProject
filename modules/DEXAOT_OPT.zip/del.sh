echo ""
echo "█▓▒▒░░DEXAOT OPT COMPILE░░░▒▒▓█"
echo ""
sleep 0.5
# Simpan tanggal instalasi
date '+%Y-%m-%d %H:%M:%S' > /data/local/tmp/touch_tweak_install_date

INSTALL_DATE=$(cat /data/local/tmp/touch_tweak_install_date 2>/dev/null || echo "Unknown")

echo "┌────────────────────────────────────────────┐"
echo "│         DEVICE AND HARDWARE INFO           │"
echo "├────────────────────────────────────────────┤"
echo "│ 📱 Device   : $(getprop ro.product.manufacturer) $(getprop ro.product.model) │"
echo "│ ⚙️ CPU      : $(getprop ro.board.platform) │"
echo "│ 🎮 GPU      : $(getprop ro.hardware) │"
echo "│ 📲 Android  : $(getprop ro.build.version.release) │"
echo "│ 📅 Install  : $INSTALL_DATE │"
echo "│ 🔰 Kernel   : $(uname -r) │"
echo "│ 🔹 Build    : $(getprop ro.build.display.id) │"
echo "│ 🛑 Root     : $(if [ $(id -u) -eq 0 ]; then echo 'Yes'; else echo 'No'; fi) │"
echo "│ 🔗 SELinux  : $(getenforce) │"
echo "└────────────────────────────────────────────┘"

echo ""
echo "█▓▒▒░░░WELCOME TO UNINSTALL░░░▒▒▓█"
echo ""
sleep 0.5
echo ""
echo "
██████╗░███████╗██╗░░░░░███████╗████████╗███████╗
██╔══██╗██╔════╝██║░░░░░██╔════╝╚══██╔══╝██╔════╝
██║░░██║█████╗░░██║░░░░░█████╗░░░░░██║░░░█████╗░░
██║░░██║██╔══╝░░██║░░░░░██╔══╝░░░░░██║░░░██╔══╝░░
██████╔╝███████╗███████╗███████╗░░░██║░░░███████╗
╚═════╝░╚══════╝╚══════╝╚══════╝░░░╚═╝░░░╚══════╝"
echo ""
sleep 0.5
echo ""
echo "PROSES UNINSTALL MODULE"
echo ""
sleep 3
# DexAOT Optimizer - Reset Edition

SDK=$(getprop ro.build.version.sdk)

if [ "$SDK" -eq 29 ]; then
    ANDROID_VERSION=10
elif [ "$SDK" -eq 30 ]; then
    ANDROID_VERSION=11
elif [ "$SDK" -eq 31 ] || [ "$SDK" -eq 32 ]; then
    ANDROID_VERSION=12
elif [ "$SDK" -eq 33 ]; then
    ANDROID_VERSION=13
elif [ "$SDK" -eq 34 ]; then
    ANDROID_VERSION=14
elif [ "$SDK" -ge 35 ]; then
    ANDROID_VERSION=15
else
    ANDROID_VERSION=Unknown
fi

echo "[•] Reset Dex2OAT & ART untuk game (Android $ANDROID_VERSION - SDK $SDK)"

# Daftar game populer
GAME_LIST=(
    com.miHoYo.GenshinImpact
    com.dts.freefireth
    com.garena.freefiremax
    com.tencent.ig
    com.pubg.krmobile
    com.pubg.imobile
    com.pubg.newstate
    com.activision.callofduty.shooter
    com.epicgames.fortnite
    com.krafton.roadtovalor
    com.mobile.legends
    com.mobile.legends.HWG
    com.mobile.legends.MI
    com.riotgames.league.wildrift
    com.riotgames.league.teamfighttactics
    com.codm
    com.roblox.client
    com.vng.pubgmobile
    com.garena.game.kgvn
    com.tencent.tmgp.sgame
    com.pixonic.wwr
    com.netease.dfjssea
    jp.konami.pesam
    com.netease.newspike
    com.garena.game.df
    com.mojang.minecraftpe
    com.mobilechess.gp
    com.levelinfinite.sgameGlobal
    com.HoYoverse.hkrpgoversea
    com.hermes.p6gameos
    com.kurogame.wutheringwaves.global
    com.HoYoverse.HonkaiStarRail
    com.miHoYo.HonkaiImpact3rd
    com.square_enix.android_googleplay.ffxv
    com.square_enix.android_googleplay.nierspww
    com.netmarble.mherosgb
    com.kabam.marvelbattle
    com.bandainamcoent.dblegends_ww
    com.bandainamcoent.opbrww
    com.nexon.bluearchive
    com.proximabeta.mf.uamo
    com.supercell.clashofclans
    com.supercell.clashroyale
    com.supercell.brawlstars
    com.supercell.boombeach
    com.supercell.hayday
    com.king.candycrushsaga
    com.king.candycrushsodasaga
    com.innersloth.spacemafia
    com.igg.android.lordsmobile
    com.plarium.raidlegends
    com.lilithgames.raziel.en
    com.lilithgame.roc.gp
    com.lilithgames.afk.google
    com.ea.gp.fifamobile
    com.ea.gp.nbamobile
    com.firsttouchgames.dls7
    com.nianticlabs.pokemongo
    com.sega.sonicdash
    com.nexon.kartdrift
    com.mihoyo.zenless
    com.bandainamcoent.shonenjump.dbzdokkan
    com.bandainamcoent.narutoblazing
    com.square_enix.android_googleplay.dffoo
    com.proximabeta.mf.uamo
    com.HoYoverse.Nap
)

# Loop reset compile untuk game
for GAME in "${GAME_LIST[@]}"; do
    if pm list packages | grep -q "$GAME"; then
        echo "[•] Reset compile untuk $GAME ..."
        pm compile -m speed "$GAME" > /dev/null 2>&1
    fi
done
# Hapus data dexopt
pm art cleanup >/dev/null 2>&1

echo "[✔] Semua game dikembalikan ke mode compile default."
echo ""
echo "Settings reverted to default."
echo ""
sleep 0.5
echo""
echo "ALL DONE DELETE[✓]"
echo""
sleep 0.5
echo""
echo "DEV LIMIT GAMING GANTENG"
echo""
sleep 0.5
echo""
echo "THANKS"
echo""
sleep 0.5
echo""
echo "SUKSES MENGHAPUS DEXAOT OPT FULL SPEED"
echo""
sleep 0.5
echo""
echo "█▓▒▒░░░THANKS FOR USING MODULE ░░░▒▒▓█"
echo""
cmd notification post -S bigtext -t 'DEXAOT OPT FULL SPEED' 'Tag' 'SUCCES REMOVED.,' > /dev/null 2>&1
