echo ""
echo "█▓▒▒░░░DEXAOT_OPT COMPILE░░░▒▒▓█"
echo ""
sleep 0.5
# Simpan tanggal instalasi
date '+%Y-%m-%d %H:%M:%S' > /data/local/tmp/touch_tweak_install_date

INSTALL_DATE=$(cat /data/local/tmp/touch_tweak_install_date 2>/dev/null || echo "Unknown")

echo "┌────────────────────────────────────────────┐"
echo "│         DEVICE AND HARDWARE INFO           │"
echo "├────────────────────────────────────────────┤"
echo "│ 📱 Device   : $(getprop ro.product.manufacturer) $(getprop ro.product.model) │"
echo "│ ⚙️ CPU      : $(getprop ro.board.platform) │"
echo "│ 🎮 GPU      : $(getprop ro.hardware) │"
echo "│ 📲 Android  : $(getprop ro.build.version.release) │"
echo "│ 📅 Install  : $INSTALL_DATE │"
echo "│ 🔰 Kernel   : $(uname -r) │"
echo "│ 🔹 Build    : $(getprop ro.build.display.id) │"
echo "│ 🛑 Root     : $(if [ $(id -u) -eq 0 ]; then echo 'Yes'; else echo 'No'; fi) │"
echo "│ 🔗 SELinux  : $(getenforce) │"
echo "└────────────────────────────────────────────┘"

echo ""
echo "█▓▒▒░░░WELCOME TO INSTALASI░░░▒▒▓█"
echo ""
sleep 0.5
echo "⠀⠀⠀⣴⣶⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣶⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣄⠀⠀⠀⠀⢰⣶
⠀⠀⢸⡿⠘⣷⡀⠀⠀⠀⣀⣀⡀⠀⠀⢀⣀⣀⣸⣿⠀⠀⣀⣀⠀⢀⣀⣀⡀⠀⢈⣉⠀⠀⣀⣀⡸⣿
⠀⢠⣿⠃⠀⣹⣧⠀⢀⣾⠋⠉⢿⣆⢰⡿⠋⠉⢻⣿⢀⣿⠋⠉⣴⡟⠋⠙⢿⣦⢸⡇⢰⡿⠋⠉⢻⣿
⠀⣾⡟⠛⠛⠛⢿⣆⠸⣿⠀⠀⢸⣧⢹⣧⠀⠀⣸⣿⢸⣿⠀⠀⢿⣇⠀⠀⣸⡿⢸⡇⢺⣧⠀⠀⣰⣿
⠘⠛⠀⠀⠀⠀⠘⠛⠘⠛⠀⠀⠘⠛⠀⠙⠻⠟⠛⠛⠘⠛⠀⠀⠈⠙⠻⠟⠋⠀⠘⠓⠀⠙⠻⠟⠛⠛
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠔⡀⠐⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡐⠂⠐⡄⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢣⢂⠁⡐⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠔⢀⠘⣠⠃⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢣⢂⠐⠈⠄⠀⠀⡀⢀⠀⠀⠀⠄⠀⠀⡀⠀⡀⠀⢀⠌⠐⠠⡸⠃⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠣⡈⠔⠘⠂⡁⠀⠄⡐⠀⠂⠄⠂⠄⠐⡀⢀⠁⠒⠂⠡⡸⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡠⠊⢁⠠⠁⠂⠄⢁⠂⠠⠁⠌⠐⠈⡀⠂⠄⠂⢈⠠⠁⠂⠁⠄⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⡠⠊⠀⠄⠂⠠⢈⠐⢈⠠⢀⠁⠂⠌⠠⢁⠐⡀⠂⠌⢀⠠⠀⠁⠂⢀⠈⠢⡀⠀⠀⠀⠀
⠀⠀⠀⢀⠊⢀⠠⠈⠀⣄⣥⣄⠂⠄⠂⠄⡈⠐⡈⠄⠂⠄⠠⠁⡐⠀⣤⣴⣄⠁⠀⠠⢀⠈⢄⠀⠀⠀
⠀⠀⠰⠁⡀⠂⠀⠠⢱⣷⣿⣿⠇⡈⠐⠠⢀⠡⠐⠠⠁⠌⠠⢁⠀⢂⣿⣿⣾⣧⠀⠠⠀⠄⡀⢡⠀⠀
⠀⠰⢁⠂⠄⠠⠁⡐⠘⠿⠿⠋⡐⠠⢁⠂⠄⢂⠁⢂⠡⢈⠐⠠⢈⠀⠙⠻⠿⠋⢀⠀⠄⠂⠠⢀⢁⠀
⢀⠆⢂⠐⠠⠁⡐⠠⠈⠄⢂⠁⡐⢀⠂⠌⡐⠠⠈⠄⠂⠄⡈⠐⠠⠈⠄⠡⠐⡀⠂⠠⠐⠀⠡⠀⠌⡄
⡜⢨⢄⡈⠄⡡⠐⠠⠁⠌⡀⢂⠐⠠⢈⠐⡀⠡⢈⠐⡈⠄⠠⢁⠂⠡⢈⠐⠠⢀⠁⠂⠄⢁⠂⢁⠂⢸"
echo ""
sleep 0.5
echo ""
echo "
██████╗░███████╗██╗░░██╗░█████╗░░█████╗░████████╗
██╔══██╗██╔════╝╚██╗██╔╝██╔══██╗██╔══██╗╚══██╔══╝
██║░░██║█████╗░░░╚███╔╝░███████║██║░░██║░░░██║░░░
██║░░██║██╔══╝░░░██╔██╗░██╔══██║██║░░██║░░░██║░░░
██████╔╝███████╗██╔╝╚██╗██║░░██║╚█████╔╝░░░██║░░░
╚═════╝░╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝░╚════╝░░░░╚═╝░░░"
echo ""
sleep 1

# DexAOT Optimizer - Game Focus Edition

SDK=$(getprop ro.build.version.sdk)

if [ "$SDK" -eq 29 ]; then
    ANDROID_VERSION=10
elif [ "$SDK" -eq 30 ]; then
    ANDROID_VERSION=11
elif [ "$SDK" -eq 31 ] || [ "$SDK" -eq 32 ]; then
    ANDROID_VERSION=12
elif [ "$SDK" -eq 33 ]; then
    ANDROID_VERSION=13
elif [ "$SDK" -eq 34 ]; then
    ANDROID_VERSION=14
elif [ "$SDK" -ge 35 ]; then
    ANDROID_VERSION=15
else
    ANDROID_VERSION=Unknown
fi

echo "[•] Deteksi Android Version: $ANDROID_VERSION (SDK $SDK)"

# Daftar game populer
GAME_LIST=(
    com.miHoYo.GenshinImpact
    com.dts.freefireth
    com.garena.freefiremax
    com.tencent.ig
    com.pubg.krmobile
    com.pubg.imobile
    com.pubg.newstate
    com.activision.callofduty.shooter
    com.epicgames.fortnite
    com.krafton.roadtovalor
    com.mobile.legends
    com.mobile.legends.HWG
    com.mobile.legends.MI
    com.riotgames.league.wildrift
    com.riotgames.league.teamfighttactics
    com.codm
    com.roblox.client
    com.vng.pubgmobile
    com.garena.game.kgvn
    com.tencent.tmgp.sgame
    com.pixonic.wwr
    com.netease.dfjssea
    jp.konami.pesam
    com.netease.newspike
    com.garena.game.df
    com.mojang.minecraftpe
    com.mobilechess.gp
    com.levelinfinite.sgameGlobal
    com.HoYoverse.hkrpgoversea
    com.hermes.p6gameos
    com.kurogame.wutheringwaves.global
    com.HoYoverse.HonkaiStarRail
    com.miHoYo.HonkaiImpact3rd
    com.square_enix.android_googleplay.ffxv
    com.square_enix.android_googleplay.nierspww
    com.netmarble.mherosgb
    com.kabam.marvelbattle
    com.bandainamcoent.dblegends_ww
    com.bandainamcoent.opbrww
    com.nexon.bluearchive
    com.proximabeta.mf.uamo
    com.supercell.clashofclans
    com.supercell.clashroyale
    com.supercell.brawlstars
    com.supercell.boombeach
    com.supercell.hayday
    com.king.candycrushsaga
    com.king.candycrushsodasaga
    com.innersloth.spacemafia
    com.igg.android.lordsmobile
    com.plarium.raidlegends
    com.lilithgames.raziel.en
    com.lilithgame.roc.gp
    com.lilithgames.afk.google
    com.ea.gp.fifamobile
    com.ea.gp.nbamobile
    com.firsttouchgames.dls7
    com.nianticlabs.pokemongo
    com.sega.sonicdash
    com.nexon.kartdrift
    com.mihoyo.zenless
    com.bandainamcoent.shonenjump.dbzdokkan
    com.bandainamcoent.narutoblazing
    com.square_enix.android_googleplay.dffoo
    com.proximabeta.mf.uamo
    com.HoYoverse.Nap
)

(
# Cmd device Config
    cmd device_config put runtime_native usap_pool_enabled true
    cmd device_config put runtime_native usap_pool_refill_delay_ms 2000
    cmd device_config put runtime_native usap_pool_size_max 6
    cmd device_config put runtime_native usap_pool_size_min 6
    cmd device_config put adservices fledge_background_fetch_thread_pool_size 8
cmd settings put system light_speed_app "$top_app"
cmd device_config put windowing_sdk com.android.window.flags.disable_object_pool false
) > /dev/null 2>&1


# Loop compile hanya untuk game di atas
for GAME in "${GAME_LIST[@]}"; do
    if pm list packages | grep -q "$GAME"; then
        echo "[•] Optimasi ART & Dex2OAT untuk $GAME ..."
        
        # Compile ringan tapi efektif
        pm compile -m speed-profile -f "$GAME" > /dev/null 2>&1
       
        # Tambahan optimasi versi Android 12+
        if [ "$ANDROID_VERSION" -ge 12 ]; then
            pm compile -m everything-profile "$GAME" > /dev/null 2>&1
        fi
    fi
done

(
# Tambahan ART tools khusus Android 14+
if [ "$ANDROID_VERSION" -ge 14 ]; then
    if pm bg-dexopt-job --enable >/dev/null 2>&1; then
        pm bg-dexopt-job --enable
        pm art dexopt-packages -r bg-dexopt
        pm art pr-dexopt-job --run
        pm art cleanup
    fi
fi
) > /dev/null 2>&1

#########################################
# AUTO PRELOAD & LOADING BOOST (NON ROOT)
#########################################
(
# Aktifkan preload game overlay
device_config put game_overlay default_use_game_preload true
device_config put game_overlay default_preload_assets true
# Kasih prioritas preload ke game
device_config put game_overlay default_preload_level high
device_config put game_overlay default_preload_optimize_latency true
# Optimalkan read-ahead storage (cache file game lebih cepat masuk RAM)
settings put global external_storage_default_read_ahead_kb 2048
# ART/Dalvik dexopt biar game lebih cepat dijalankan (precompiled)
device_config put runtime dexopt_game true
device_config put runtime dexopt_speed_profile true
# Minimalkan delay preload thread
device_config put game_overlay default_preload_thread_priority urgent
) > /dev/null 2>&1
echo "[✔] Optimasi Dex2OAT & ART untuk game selesai!"

sleep 0.5

echo""
echo "DEXAOT OPT FULL SPEED"
echo""
sleep 0.5
echo""
echo "DEXAOT OPT COMPILE ACTIVE"
sleep 0.5
echo""
echo "‼️DON'T REBOOT ‼️"
echo""
sleep 0.5
echo""
echo "DEV LIMIT GAMING GANTENG"
echo""
sleep 0.5
echo""
echo "THANKS"
echo""
sleep 0.5
echo""
echo "ENJOY YOUR GAMING"
echo""
sleep 0.5
echo""
echo ""█▓▒▒░░░THANKS FOR USING MODULE ░░░▒▒▓█
echo""

cmd notification post -S bigtext -t 'DexAotOpt Full Speed' 'Tag' 'SUCCES ACTIVE.,' > /dev/null 2>&1