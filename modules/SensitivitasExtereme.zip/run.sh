dev=Agung Developer
version=1.0
cr=NeonProject
status=SENSI EXTREME
sleep 1.5
echo ""
echo "[ SENSI EXTREME INFORMATION ]"
echo "Developer : ${dev}"
echo "Version   : ${version}"
echo "status    : ${status}"
echo "Copyright : ${cr}"
echo ""
sleep 1.5
echo "[ LOADING SENSI EXTREME ]"
sleep 0.8
echo "[■□□□□□□□□□]  "
sleep 0.7
echo "[■■□□□□□□□□]  "
sleep 2
echo "[■■■□□□□□□□]  "
sleep 2
echo "[■■■■□□□□□□]  "
sleep 2
echo "[■■■■■□□□□□]  "
sleep 2
echo "[■■■■■■□□□□]  "
sleep 2
echo "[■■■■■■■□□□]  "
sleep 2
echo "[■■■■■■■■□□]  "
sleep 2
echo "[■■■■■■■■■□] "
sleep 1.5
echo "[■■■■■■■■■■] "
echo ""
echo " ADD SENSIX.... "
wm size 1440x3120
wm density 480  # Menambahkan DPI untuk meningkatkan ketajaman dan responsivitas layar
echo " EASY SWIPE"
external_exe() {
x1=$(expr $RANDOM % 1000 + 1)
y1=$(expr $RANDOM % 1000 + 1)
x2=$(expr $RANDOM % 1000 + 1)
y2=$(expr $RANDOM % 1000 + 1)
duration=$(expr $RANDOM % 800 + 300)  # Mengurangi durasi swipe untuk gerakan lebih cepat
swipe_command="input swipe $x1 $y1 $x2 $y2 $duration -1"
$swipe_command
}
aim_tracking_opt() {
  local coordinate=$1
  if [ $coordinate -lt 0 ]; then
    coordinate=0
  elif [ $coordinate -gt 1000 ]; then 
    coordinate=1000
  fi
  echo $coordinate
}
sensi_calibrar() {
  local x=$(expr $RANDOM % 1000 + 1)
  local y=$(expr $RANDOM % 1000 + 1)
  local duration=$(expr $RANDOM % 800 + 300)  # Mengurangi durasi untuk swipe lebih responsif

  external_exe swipe $(aim_tracking_opt $x) $(aim_tracking_opt $y) 2000 2000 $duration
  external_exe swipe $(aim_tracking_opt $x) $(aim_tracking_opt $y) 2000 0 $duration
  external_exe swipe $(aim_tracking_opt $x) $(aim_tracking_opt $y) 0 2000 $duration 
  external_exe swipe $(aim_tracking_opt $x) $(aim_tracking_opt $y) 0 0 $duration

  external_exe swipe $(aim_tracking_opt $x) $(aim_tracking_opt $y) 2000 2000 $duration
  external_exe swipe $(aim_tracking_opt $x) $(aim_tracking_opt $y) 0 2000 $duration

rm -r /sdcard/Android/data/com.dts.freefireth/cache/*> /dev/null 2>&1
rm -r /sdcard/Android/data/com.dts.freefiremax/cache/*> /dev/null 2>&1
rm -r /sdcard/Android/data/com.dts.freefireth/cache/*> /dev/null 2>&1
rm -r /sdcard/Android/data/com.dts.freefireth/files/il2cpp/*> /dev/null 2>&1
rm -r /sdcard/Android/data/com.dts.freefiremax/files/il2cpp/*> /dev/null 2>&1
rm -f /data/local/traces/*> /dev/null 2>&1
rm -f /sdcard/Android/data/com.dts.freefireth/files/ffrtc_log.txt*> /dev/null 2>&1
rm -f /sdcard/Android/data/com.dts.freefireth/files/ffrtc_log_bak.txt*> /dev/null 2>&1
rm -f /sdcard/Android/data/com.dts.freefiremax/files/ffrtc_log.txt*> /dev/null 2>&1
rm -f /sdcard/Android/data/com.dts.freefiremax/files/ffrtc_log_bak.txt*> /dev/null 2>&1
}
external_exe
sensi_calibrar
echo " SLIPPERY SCREEN "
etc 1 zen_mode> /dev/null 2>&1
etc ENABLE sem_enhanced_cpu_responsiveness> /dev/null 2>&1
sensi 1 screen_game_mode> /dev/null 2>&1
sensi 1 perf_game_oom_enable> /dev/null 2>&1
sensi 60 rt_templimit_bottom> /dev/null 2>&1
sensi 72 rt_templimit_ceiling> /dev/null 2>&1
game 1 speed_mode_enable> /dev/null 2>&1
etc 1 ambient_low_bit_enabled> /dev/null 2>&1
etc 1 ambient_low_bit_enabled_dev> /dev/null 2>&1
sleep 1
echo " SUPER RESPONSIVE  "
function optimize_free {
dumpsys deviceidle whitelist +com.dts.freefireth
dumpsys deviceidle whitelist +com.dts.freefiremax
appops set com.dts.freefireth RUN_IN_BACKGROUND allow
appops set com.dts.freefiremax RUN_IN_BACKGROUND allow
cmd device_config put touchscreen input_drag_min_switch_speed 400  # Mengurangi kecepatan switch untuk swipe lebih cepat
cmd package compile -m everything-profile -f com.dts.freefireth
cmd package compile -m everything-profile -f com.dts.freefiremax
cmd package compile -m speed --secondary-dex -f com.dts.freefireth
cmd package compile -m speed --secondary-dex -f com.dts.freefiremax
cmd sensorservice set-uid-state com.dts.freefiremax activity
cmd sensorservice set-uid-state com.dts.freefireth activity
pm log-visibility --disable com.dts.freefireth
pm log-visibility --disable com.dts.freefiremax
cmd device_config put touchscreen input_drag_min_switch_speed 400
cmd game mode performance com.dts.freefireth
cmd game mode performance com.dts.freefiremax
cmd game mode performance com.mobile.legends
cmd game mode performance com.tencent.ig
cmd game mode performance com.garena.game.codm
cmd game mode performance com.miHoYo.GenshinImpact
cmd game mode performance com.mobilelegends.hwag
cmd game mode performance com.netease.newspike
cmd package compile -m speed --check-prof false -f com.dts.freefireth
cmd package compile -m speed --check-prof false -f com.dts.freefiremax
}
echo " HIGH PERFORMANCE  "
game 250 aim_lock_timeout> /dev/null 2>&1
game 150 aim_lock_timeout> /dev/null 2>&1
settings put system view.scroll_friction 0
settings put secure multi_press_timeout 120  # Mengurangi timeout untuk respons lebih cepat
settings put secure long_press_timeout 120  # Mengurangi timeout untuk respons lebih cepat
echo " STABLE JARINGAN "
internet_tweaks=(
net wifi_score_params rssi2=-95:-85:-73:-60,rssi5=-85:-82:-70:-57
net wifi_coverage_extend_feature_enabled 0
net wifi_networks_available_notification_on 0
net wifi_poor_connection_warning 0
net wifi_scan_always_enabled 0
net wifi_scan_throttle_enabled 0
net wifi_verbose_logging_enabled 0
net wifi_suspend_optimizations_enabled 1
net wifi_wakeup_enabled 0
net sysui_powerui_enabled 1
net global ble_scan_always_enabled 0
)
echo " UNLOCK REFRESH RATE "
settings put system min_refresh_rate 120
settings put system peak_refresh_rate 120
settings put system user_refresh_rate 120
echo " GET FPS ASISST "
(
setprop debug.egl.force_msaa 0
setprop debug.egl.force_fxaa 0
setprop debug.egl.force_taa 0
setprop debug.egl.force_ssaa 0
setprop debug.egl.force_smaa 0
setprop debug.egl.hw 1
setprop debug.egl.buffcount 4
settings put global video.accelerate.hw 1
settings put global view.scroll_friction 0
settings put global persist.cpu.gov.performance performance
settings put global persist.cpu.gov.performance 1
settings put global game_driver_prerelease_opt_in_apps com.dts.freefiremax
settings put global game_driver_prerelease_opt_in_apps com.dts.freefireth
)> /dev/null 2>&1
echo " ENHANCED TOUCH SENSITIVITY "
(
settings put system touch_sensitivity 1
setprop persist.sys.touch.responsiveness 1
setprop persist.sys.touch.pressed_threshold 40  # Mengurangi ambang batas tekanan untuk sentuhan lebih sensitif
setprop debug.input.touch.filter 0
cmd device_config put input_native_boot touch.input.ignore_events 0
cmd device_config put input_native_boot touch.input.pressure.scale 0.8  # Mengurangi skala tekanan untuk sentuhan lebih licin
cmd device_config put input_native_boot touch.input.size.scale 0.7  # Mengurangi skala ukuran untuk presisi lebih tinggi
setprop persist.sys.touch.sampling_rate 120  # Meningkatkan sampling rate sentuhan
setprop debug.input.touch.latency 0  # Mengurangi latensi sentuhan
cmd device_config put input_native_boot touch.input.velocity.scale 0.9  # Menyesuaikan skala kecepatan sentuhan
)> /dev/null 2>&1
sleep 1
echo ""
echo "Sensitivitas Extreme by Agung Dev"