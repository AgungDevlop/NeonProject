#!/bin/bash
#
# Vexiro Modules Installer - Vorvex Edition
# Version 8
#

printf "\n"
LOGO="
██╗░░░██╗███████╗██╗░░██╗██╗██████╗░░█████╗░ 
██║░░░██║██╔════╝╚██╗██╔╝██║██╔══██╗██╔══██╗ 
╚██╗░██╔╝█████╗░░░╚███╔╝░██║██████╔╝██║░░██║ 
░╚████╔╝░██╔══╝░░░██╔██╗░██║██╔══██╗██║░░██║ 
░░╚██╔╝░░███████╗██╔╝╚██╗██║██║░░██║╚█████╔╝ 
░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚═╝╚═╝░░╚═╝░╚════╝░ 
"
INFO="
📦 Vexiro Modules
⚡ Version — 8 Free Version
🔥 Vorvex Edition (Installer)
🦅 Name Modules [ SmoothRAM ]
"

print_step() {
    local msg="$1"
    local delay="$2"
    printf "[ - ] %s...\n" "$msg"
    sleep "$delay"
}

printf "%s\n" "$LOGO"
printf "%s\n" "$INFO"
printf "\n"
sleep 1

STEPS=(
    " Starting installation:1"
    " Checking required modules:2"
    " Installing core modules:3"
    " Applying system patches:2"
    " Configuring system files:2"
    " Finalizing installation:1"
)

#$#$MAIN-DATA#$#$
z="
";GFz='_on_';Fz=' glo';xBz='0.5';ODz='all';hBz='ha_l';bEz='n_en';Iz='ator';Vz='wind';lBz='45';jDz='-9 t';pHz='}';MHz='& \';hGz='pp" ';vEz=' sec';NHz='tenc';EGz='fi';cCz='ow_r';BDz='upgr';EFz='ver_';WEz='ays_';UEz='scan';rBz='apps';AHz=' \';bGz='brev';vDz='top ';TBz='her ';FDz=' 80';mFz='port';xCz='480,';vFz='$(cm';DEz='ndro';NBz='e';iGz='== "';IBz='ue';sz='lse';MFz='ion_';dHz='ram_';nEz='mmen';qFz='/nul';CEz='om.a';KDz='re 2';GEz='.tom';yFz='rep ';TEz='led ';eFz='ed 0';mBz='ha_t';hDz='ed';Rz='nima';eEz='mobi';EHz='inIm';WFz='er_m';MBz='fals';VFz='mast';yz='conf';az='ager';cFz='issi';JBz='amp_';DDz='pres';BFz='ep 0';tFz='if [';iz='ses ';uFz='[ ! ';Az='{';XGz='= "m';Dz='ings';kBz=' 0.5';fBz='_ini';tGz='sapp';PHz='ig" ';WHz=']]; ';cDz='bsto';lz='ble_';WBz='gcm_';aGz='dge.';Nz='0';dFz='llow';gz='d_pr';YFz='near';FCz='sses';XHz='then';YEz='ord_';aDz='stop';nz='tor_';LFz='_act';xDz='p"';QBz='e fa';bz='_con';KGz=' pac';oEz='dati';TFz='p_mo';RGz='cut ';UBz='prel';wDz='"$ap';PGz='es -';QFz='inte';CCz='hant';QEz='rts_';LBz='ble ';RFz='llig';HCz='ts b';PFz='r 0';ZCz='sys.';ICz='g_lo';IGz='in $';QDz='t_ba';jBz='cale';Hz='anim';xEz='adap';mGz='kend';THz='le.l';KCz='m_mu';SHz='agik';jCz='tage';jz='8';ZFz='by_s';yCz='2457';HEz='air_';eHz='expa';mHz='imit';WCz=' tru';jGz='eu.s';sFz='&1 &';XDz='rop_';dBz='_max';mCz='e 51';eDz='ill ';uEz=' 0';kCz='zram';wFz='d -l';qEz='wifi';bBz='ha_e';yDz='pm d';tBz='max ';eBz=' 42';yGz='] &&';Sz='tion';gDz='ston';wEz='ure ';cBz='mpty';ez='ax_c';gEz='ata_';lDz='tone';KFz='send';YHz='p 1';MGz=' lis';eCz='rue';cHz=' 1';qGz='\';mEz='reco';yEz='tive';NEz='ake_';QHz='vexi';ABz='ig.s';bFz='perm';nHz=' 16';UFz='de 0';XCz=' sys';FEz='hell';pCz='minf';rz='s fa';vz='t ev';JEz='on_e';NFz='app_';kFz='urit';jFz='_sec';UCz='m_de';MEz='on_w';qDz='topp';ACz='10';ADz='6';PDz='limi';Bz='(';YGz='e.pi';lEz='ork_';pDz='ps_s';sEz='ways';kGz='isik';dCz='am t';RHz='ro.m';CHz='Yo.G';wBz='.5';Yz='vity';BHz='miHo';hEz='alwa';REz='logg';FHz='pact';iFz='a 0';NCz='ur_m';oGz='" ]]';Gz='bal ';Kz='atio';GGz='for ';dDz='ned';IHz='fire';Qz='on_a';tCz='2,12';gCz='_fre';MDz='am k';xGz='s" ]';uDz='ce-s';DBz='le f';uz='exop';gGz=' "$a';RDz='ckgr';RCz='forc';XEz='hotw';OHz='ent.';sCz=',819';EEz='id.s';tz='bg_d';GHz='dts.';lHz='ru_l';BBz='pcm_';IFz='slee';nFz='s 0';ZHz='echo';FFz='vate';dz='ts m';VGz='; do';HGz='app ';wz='eryt';nGz='ebug';JGz='(cmd';VHz='ds" ';yBz='ses=';YCz='tem ';DGz='exit';iBz='mk_s';HFz='dock';VDz='es 2';iHz='dby_';JCz='w_me';tEz='bled';oHz='&1';VCz='vice';kz='_ena';LHz=']] &';KHz='th" ';xz='hing';gBz='t 32';Zz='_man';aHz=' ""';dEz='d 0';mDz='d';wCz='4,20';XFz='otio';ECz='roce';SBz='aunc';CDz='ade_';fEz='le_d';GBz='_ski';iDz='all ';WDz='vm_d';sGz='what';IDz='e_pr';rFz='l 2>';iEz='ys_o';rCz='4096';uCz='288,';hz='oces';Ez=' put';OCz='low_';Xz='acti';WGz='p" =';SGz='-f 2';qBz='dha_';GDz='down';SDz='ound';LCz='lt 1';mz='moni';SFz='ent_';aCz='hapt';XBz='ig.d';KEz='ngin';oBz='te 2';kDz='ombs';wGz='tool';LDz='5';gHz='ize ';Oz='tran';IEz='moti';AGz=') ]]';aBz='x 16';bHz='done';SCz='e_lo';LGz='kage';NDz='ill-';SEz='ing_';YBz='ha_c';CFz='scre';hCz='w_pe';lCz='_siz';xFz=' | g';Uz='le 0';OGz='ckag';pEz='ons_';jHz='ed_a';bCz='ic.l';nCz='2';TGz=' -d ';BEz='le c';AEz='isab';UDz='cess';Tz='_sca';PCz='ram ';Wz='ow_a';OEz='up 0';oz='phan';fCz='swap';aFz='cann';rGz='com.';tDz=' for';RBz='db_l';OBz='db_e';JHz='max"';cz='stan';nDz='e_al';PBz='nabl';lGz='.hac';CBz='enab';iCz='rcen';qz='proc';fGz='[[ !';bDz=' tom';vGz='ea.v';fHz='nd_s';AFz='_sle';QCz='true';oFz=') > ';Mz='ale ';VBz='oad_';pBz='.3';NGz='t pa';HHz='free';rDz='ed 1';KBz='spcm';DHz='ensh';DFz='ensa';UHz='egen';GCz=' 5';vBz='min ';CGz='en';TCz='w_ra';hHz='1024';hFz='denw';OFz='erro';Lz='n_sc';kHz='pp_l';FGz='p 2';HDz='grad';LEz='e 0';ZDz='es 1';pGz=' && ';FBz='kill';pFz='/dev';PEz='_sta';aEz='ctio';ZBz='d_ma';HBz='p tr';sDz='cmd ';oDz='l_ap';nBz='h_ra';jEz='n 0';cGz='ent"';DCz='om_p';uBz='64';MCz='ts c';fDz='tomb';UGz='":")';cEz='able';BCz='ax_p';qCz='ree ';TDz='_pro';uGz='omar';eGz='&& \';rEz='n_al';ZEz='dete';Cz='sett';YDz='cach';BGz='; th';Pz='siti';VEz='_alw';Jz='_dur';JDz='essu';kEz='netw';fz='ache';dGz=' ]] ';JFz='p 0';gFz='ten_';lFz='y_re';EBz='alse';vCz='1638';sBz='_bg_';oCz='lmk_';pz='tom_';ZGz='ebri';fFz='raku';QGz='3 | ';EDz='sure';
eval "$Az$z$Bz$z$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$z$Cz$Dz$Ez$Fz$Gz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$z$Cz$Dz$Ez$Fz$Gz$Vz$Wz$Rz$Sz$Tz$Uz$z$Cz$Dz$Ez$Fz$Gz$Xz$Yz$Zz$az$bz$cz$dz$ez$fz$gz$hz$iz$jz$z$Cz$Dz$Ez$Fz$Gz$Cz$Dz$kz$lz$mz$nz$oz$pz$qz$rz$sz$z$Cz$Dz$Ez$Fz$Gz$tz$uz$vz$wz$xz$z$Cz$Dz$Ez$Fz$Gz$yz$ABz$BBz$CBz$DBz$EBz$z$Cz$Dz$Ez$Fz$Gz$yz$ABz$BBz$FBz$GBz$HBz$IBz$z$Cz$Dz$Ez$Fz$Gz$yz$ABz$JBz$KBz$kz$LBz$MBz$NBz$z$Cz$Dz$Ez$Fz$Gz$yz$ABz$BBz$OBz$PBz$QBz$sz$z$Cz$Dz$Ez$Fz$Gz$yz$ABz$BBz$RBz$SBz$TBz$MBz$NBz$z$Cz$Dz$Ez$Fz$Gz$yz$ABz$BBz$UBz$VBz$CBz$DBz$EBz$z$Cz$Dz$Ez$Fz$Gz$yz$ABz$BBz$WBz$FBz$kz$LBz$MBz$NBz$z$Cz$Dz$Ez$Fz$Gz$yz$XBz$YBz$fz$ZBz$aBz$z$Cz$Dz$Ez$Fz$Gz$yz$XBz$bBz$cBz$dBz$eBz$z$Cz$Dz$Ez$Fz$Gz$yz$XBz$bBz$cBz$fBz$gBz$z$Cz$Dz$Ez$Fz$Gz$yz$XBz$hBz$iBz$jBz$kBz$lBz$z$Cz$Dz$Ez$Fz$Gz$yz$XBz$mBz$nBz$oBz$pBz$z$Cz$Dz$Ez$Fz$Gz$yz$ABz$qBz$rBz$sBz$tBz$uBz$z$Cz$Dz$Ez$Fz$Gz$yz$ABz$qBz$rBz$sBz$vBz$jz$z$Cz$Dz$Ez$Fz$Gz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$wBz$z$Cz$Dz$Ez$Fz$Gz$Vz$Wz$Rz$Sz$Tz$Uz$wBz$z$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$xBz$z$Cz$Dz$Ez$Fz$Gz$Xz$Yz$Zz$az$bz$cz$dz$ez$fz$gz$hz$yBz$ACz$z$Cz$Dz$Ez$Fz$Gz$Xz$Yz$Zz$az$bz$cz$dz$BCz$CCz$DCz$ECz$FCz$GCz$z$Cz$Dz$Ez$Fz$Gz$Xz$Yz$Zz$az$bz$cz$HCz$ICz$JCz$KCz$LCz$z$Cz$Dz$Ez$Fz$Gz$Xz$Yz$Zz$az$bz$cz$MCz$NCz$ez$fz$gz$hz$iz$jz$z$Cz$Dz$Ez$Fz$Gz$OCz$PCz$QCz$z$Cz$Dz$Ez$Fz$Gz$RCz$SCz$TCz$UCz$VCz$WCz$NBz$z$Cz$Dz$Ez$XCz$YCz$ZCz$aCz$bCz$cCz$dCz$eCz$z$Cz$Dz$Ez$Fz$Gz$fCz$gCz$SCz$hCz$iCz$jCz$GCz$z$Cz$Dz$Ez$Fz$Gz$kCz$kz$LBz$QCz$z$Cz$Dz$Ez$Fz$Gz$kCz$lCz$mCz$nCz$z$Cz$Dz$Ez$Fz$Gz$oCz$pCz$qCz$rCz$sCz$tCz$uCz$vCz$wCz$xCz$yCz$ADz$z$Cz$Dz$Ez$Fz$Gz$oCz$BDz$CDz$DDz$EDz$FDz$z$Cz$Dz$Ez$Fz$Gz$oCz$GDz$HDz$IDz$JDz$KDz$LDz$z$MDz$NDz$ODz$z$Cz$Dz$Ez$Fz$Gz$PDz$QDz$RDz$SDz$TDz$UDz$VDz$z$Cz$Dz$Ez$XCz$YCz$WDz$XDz$YDz$ZDz$z$aDz$bDz$cDz$dDz$z$MDz$eDz$fDz$gDz$hDz$z$FBz$iDz$jDz$kDz$lDz$mDz$z$Cz$Dz$Ez$XCz$YCz$RCz$nDz$oDz$pDz$qDz$rDz$z$sDz$Xz$Yz$tDz$uDz$vDz$wDz$xDz$z$yDz$AEz$BEz$CEz$DEz$EEz$FEz$GEz$cDz$dDz$z$Cz$Dz$Ez$XCz$YCz$HEz$IEz$JEz$KEz$LEz$z$Cz$Dz$Ez$XCz$YCz$HEz$IEz$MEz$NEz$OEz$z$Cz$Dz$Ez$Fz$Gz$Xz$Yz$PEz$QEz$REz$SEz$CBz$TEz$Nz$z$Cz$Dz$Ez$Fz$Gz$lz$UEz$VEz$WEz$CBz$TEz$Nz$z$Cz$Dz$Ez$Fz$Gz$XEz$YEz$ZEz$aEz$bEz$cEz$dEz$z$Cz$Dz$Ez$Fz$Gz$eEz$fEz$gEz$hEz$iEz$jEz$z$Cz$Dz$Ez$Fz$Gz$kEz$lEz$mEz$nEz$oEz$pEz$CBz$TEz$Nz$z$Cz$Dz$Ez$Fz$Gz$qEz$Tz$rEz$sEz$kz$tEz$uEz$z$Cz$Dz$Ez$vEz$wEz$xEz$yEz$AFz$BFz$z$Cz$Dz$Ez$vEz$wEz$CFz$DFz$EFz$Xz$FFz$GFz$HFz$uEz$z$Cz$Dz$Ez$vEz$wEz$CFz$DFz$EFz$Xz$FFz$GFz$IFz$JFz$z$Cz$Dz$Ez$vEz$wEz$CFz$DFz$EFz$CBz$TEz$Nz$z$Cz$Dz$Ez$vEz$wEz$KFz$LFz$MFz$NFz$OFz$PFz$z$Cz$Dz$Ez$XCz$YCz$QFz$RFz$SFz$IFz$TFz$UFz$z$Cz$Dz$Ez$XCz$YCz$VFz$WFz$XFz$jEz$z$Cz$Dz$Ez$XCz$YCz$IEz$JEz$KEz$LEz$z$Cz$Dz$Ez$XCz$YCz$YFz$ZFz$aFz$SEz$CBz$TEz$Nz$z$Cz$Dz$Ez$XCz$YCz$YFz$ZFz$aFz$SEz$bFz$cFz$Qz$dFz$eFz$z$Cz$Dz$Ez$XCz$YCz$fFz$gFz$hFz$iFz$z$Cz$Dz$Ez$XCz$YCz$KFz$jFz$kFz$lFz$mFz$nFz$z$oFz$pFz$qFz$rFz$sFz$z$Bz$z$tFz$uFz$vFz$wFz$xFz$yFz$Xz$Yz$AGz$BGz$CGz$z$DGz$z$EGz$z$oFz$pFz$qFz$rFz$sFz$z$IFz$FGz$z$Bz$z$GGz$HGz$IGz$JGz$KGz$LGz$MGz$NGz$OGz$PGz$QGz$RGz$SGz$TGz$UGz$VGz$z$tFz$uFz$wDz$WGz$XGz$YGz$ZGz$aGz$bGz$cGz$dGz$eGz$z$fGz$gGz$hGz$iGz$jGz$kGz$lGz$mGz$nGz$oGz$pGz$qGz$z$fGz$gGz$hGz$iGz$rGz$sGz$tGz$oGz$pGz$qGz$z$fGz$gGz$hGz$iGz$rGz$uGz$vGz$wGz$xGz$yGz$AHz$z$fGz$gGz$hGz$iGz$rGz$BHz$CHz$DHz$EHz$FHz$oGz$pGz$qGz$z$fGz$gGz$hGz$iGz$rGz$GHz$HHz$IHz$JHz$dGz$eGz$z$fGz$gGz$hGz$iGz$rGz$GHz$HHz$IHz$KHz$LHz$MHz$z$fGz$gGz$hGz$iGz$rGz$NHz$OHz$PHz$LHz$MHz$z$fGz$gGz$hGz$iGz$rGz$QHz$RHz$SHz$xGz$yGz$AHz$z$fGz$gGz$hGz$iGz$rGz$eEz$THz$UHz$VHz$WHz$XHz$z$IFz$YHz$z$ZHz$aHz$z$EGz$z$bHz$z$oFz$pFz$qFz$rFz$sFz$z$Bz$z$Cz$Dz$Ez$Fz$Gz$kCz$kz$tEz$cHz$z$Cz$Dz$Ez$Fz$Gz$dHz$eHz$fHz$gHz$hHz$Nz$z$Cz$Dz$Ez$Fz$Gz$Xz$Yz$Zz$az$bz$cz$dz$ez$fz$gz$hz$iz$jz$z$Cz$Dz$Ez$Fz$Gz$NFz$cz$iHz$CBz$TEz$QCz$z$Cz$Dz$Ez$Fz$Gz$YDz$jHz$kHz$lHz$mHz$nHz$z$oFz$pFz$qFz$rFz$oHz$z$pHz"

for step in "${STEPS[@]}"; do
    IFS=":" read -r text delay <<< "$step"
    print_step "$text" "$delay"
done

printf "\n[✔] Installation completed successfully!\n\n\n"