#!/bin/bash
#
# Vexiro Modules unistaller - Vorvex Edition
# Version 8
#

printf "\n"
LOGO="
██╗░░░██╗███████╗██╗░░██╗██╗██████╗░░█████╗░ 
██║░░░██║██╔════╝╚██╗██╔╝██║██╔══██╗██╔══██╗ 
╚██╗░██╔╝█████╗░░░╚███╔╝░██║██████╔╝██║░░██║ 
░╚████╔╝░██╔══╝░░░██╔██╗░██║██╔══██╗██║░░██║ 
░░╚██╔╝░░███████╗██╔╝╚██╗██║██║░░██║╚█████╔╝ 
░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚═╝╚═╝░░╚═╝░╚════╝░ 
"
INFO="
📦 Vexiro Modules
⚡ Version — 8 Free Version
🔥 Vorvex Edition (unistaller)
🦅 Name Modules [ SmoothRAM ]
"

print_step() {
    local msg="$1"
    local delay="$2"
    printf "[ - ] %s...\n" "$msg"
    sleep "$delay"
}

printf "%s\n" "$LOGO"
printf "%s\n" "$INFO"
printf "\n"
sleep 1

STEPS=(
    " Starting Uninstallation:1"
    " Checking required modules:2"
    " Installing core modules:3"
    " Applying system patches:2"
    " Configuring system files:2"
    " Finalizing Uninstallation:1"
)

#$#$MAIN-DATA#$#$
z="
";Zz='s ma';dGz='ensh';bDz='ell.';AGz='ebri';MGz='.hac';bEz='ive_';YDz='m.an';ACz='a_lm';bCz='m';qEz='pp_e';Nz='al r';yCz='anto';jEz='ock';CBz='al t';cz='_pro';kGz=']] &';pCz='de_p';Tz='ctiv';EEz='_ena';dBz='cm_k';cCz='wap_';oFz='es -';XEz='led';NBz='al s';gFz='app ';gBz='g.sa';iEz='on_d';VBz='om_p';GEz='al m';GFz='ermi';jFz=' pac';OFz='rity';MEz='al n';uCz='rade';sGz='mobi';uGz='egen';qGz='ro.m';oDz='gine';KDz='_bac';YGz='s" ]';DDz='s bg';BEz='otwo';TGz='what';eDz='em f';kCz='mk_m';lGz='& \';DBz='rans';KGz='eu.s';hz='by_e';dFz='fi';TFz='[ ! ';IFz='n_al';CEz='rd_d';qFz='cut ';bz='ched';PDz='em v';lBz='b_la';uEz='lige';RCz='_low';REz='atio';kFz='kage';iGz='max"';gDz='_app';qBz='ad_e';Sz='al a';pz='mit';LBz='indo';HCz='pps_';IBz='scal';hFz='in $';nDz='n_en';DFz='y_sc';mFz='t pa';xBz='max';dDz='ston';lDz='ir_m';BDz='oces';QEz='mend';UEz='scan';xGz='then';AEz='al h';qCz='ress';qz=') > ';HDz='s cu';sBz='g.dh';SDz='star';FGz='&& \';pDz='n_wa';oCz='pgra';iFz='(cmd';gGz='dts.';JFz='lowe';vDz='le_s';cGz='Yo.G';lCz='infr';rBz='cm_g';Jz='d  0';eCz='_per';aBz='onfi';CCz='ale';uDz='ng_e';uBz='_max';VDz='oned';QDz='m_dr';Yz='tant';ZFz=') ]]';KFz='em r';MBz='w_an';ZEz='re a';vBz='a_em';UBz='hant';kEz='on_s';jGz='th" ';Bz='sett';CFz='earb';Gz=' zra';gCz='age';XDz='e co';QGz=' && ';LFz='akut';NDz='proc';KEz='lway';BGz='dge.';sz='/nul';vz='nima';OCz='am';tDz='oggi';DEz='etec';yFz='e.pi';Oz='am_e';UFz='$(cm';fGz='pact';tCz='owng';ODz='esse';qDz='ke_u';RBz='le_m';Xz='cons';tBz='a_ca';uFz='; do';vCz='_pre';rDz='p';wEz='_mod';BCz='k_sc';DGz='ent"';IGz='pp" ';iz='nabl';EFz='anni';nEz='end_';NGz='kend';sDz='ts_l';WDz='pm e';KCz='in';JEz='ta_a';nCz='mk_u';xEz='em m';jBz='cm_d';UDz='mbst';TCz='_dev';Vz='mana';pGz='vexi';FEz='bled';vGz='ds" ';SEz='ns_e';nBz='er';hCz='al z';YBz='g_de';LCz='s';fz='pp_s';IEz='e_da';mBz='unch';LGz='isik';cDz='tomb';EGz=' ]] ';mEz='er_e';ZGz='] &&';OBz='etti';wGz=']]; ';LEz='s_on';jDz='d';hEz='ate_';GBz='imat';JDz='imit';QFz='orts';nGz='ent.';sCz='mk_d';fCz='cent';lz='ache';hDz='s_st';bFz='en';jz='ed';Pz='xpan';eEz='cree';VEz='_alw';UGz='sapp';oBz='cm_p';dCz='free';gz='tand';rEz='rror';rGz='agik';vFz='"$ap';fBz='skip';xCz='x_ph';RGz='\';lFz=' lis';dEz='re s';WFz=' | g';rFz='-f 2';KBz='al w';pBz='relo';yGz='p 1';OEz='rk_r';PFz='_rep';CGz='brev';bGz='miHo';wDz='can_';SFz='if [';mCz='ee';PBz='ngs_';HFz='ssio';oEz='acti';nz='p_lr';yDz='ys_e';mGz='tenc';Az='(';xz='dura';Lz='ete ';Ez='  gl';Kz=' del';bBz='g.sp';XCz='ys.h';Mz='glob';VCz='syst';OGz='ebug';XGz='tool';JBz='e';lEz='leep';Cz='ings';tFz='":")';fFz='for ';EBz='itio';aGz=' \';QCz='orce';Uz='ity_';Iz='able';eFz='p 2';wz='tor_';AHz='done';YEz='secu';GDz='t';PEz='ecom';HGz=' "$a';ADz='m_pr';VGz='omar';pFz='3 | ';PGz='" ]]';HBz='ion_';BFz='em n';mDz='otio';JCz='ax';eBz='ill_';oGz='ig" ';EDz='_mem';FDz='_mul';aFz='; th';PCz='al f';IDz='r_ma';TDz='t to';Rz='ze';NCz='ow_r';fDz='_all';WGz='ea.v';ABz='_sca';WCz='em s';wFz='p" =';YFz='vity';uz='&1';XFz='rep ';vEz='nt_s';YCz='apti';nFz='ckag';xDz='alwa';ZCz='c.lo';fEz='nsav';Qz='d_si';MFz='en_d';ZDz='droi';aEz='dapt';DCz='a_th';GCz='ha_a';WEz='ays_';RDz='op_c';RFz='&1 &';QBz='enab';ez='es';xFz='= "m';jCz='size';iDz='oppe';rz='/dev';mz='d_ap';MCz='al l';cBz='cm_e';UCz='ice';yBz='init';SCz='_ram';Dz=' put';BBz='le';rCz='ure';hBz='mp_s';iBz='pcm_';sEz='em i';cEz='slee';LDz='kgro';ECz='_rat';ICz='bg_m';yEz='aste';aDz='d.sh';gEz='er_a';kz='al c';FCz='g.sd';XBz='al b';hGz='fire';kBz='b_en';oz='u_li';TBz='or_p';yz='tion';NEz='etwo';Hz='m_en';dz='cess';FFz='ng_p';ZBz='xopt';tGz='le.l';cFz='exit';FBz='n_an';SBz='onit';wBz='pty_';aCz='w_ra';iCz='ram_';kDz='em a';JGz='== "';tEz='ntel';az='x_ca';TEz='ifi_';VFz='d -l';CDz='ses';tz='l 2>';sFz=' -d ';WBz='rocs';Fz='obal';HEz='obil';NFz='enwa';Wz='ger_';eGz='inIm';pEz='on_a';AFz='r_mo';GGz='[[ !';MDz='und_';wCz='ssur';SGz='com.';
eval "$Az$z$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$z$Bz$Cz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$z$Bz$Cz$Kz$Lz$Mz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$cz$dz$ez$z$Bz$Cz$Kz$Lz$Mz$Sz$fz$gz$hz$iz$jz$z$Bz$Cz$Kz$Lz$Mz$kz$lz$mz$nz$oz$pz$z$qz$rz$sz$tz$uz$z$Az$z$Bz$Cz$Kz$Lz$Mz$Sz$vz$wz$xz$yz$ABz$BBz$z$Bz$Cz$Kz$Lz$Mz$CBz$DBz$EBz$FBz$GBz$HBz$IBz$JBz$z$Bz$Cz$Kz$Lz$Mz$KBz$LBz$MBz$GBz$HBz$IBz$JBz$z$Bz$Cz$Kz$Lz$Mz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$cz$dz$ez$z$Bz$Cz$Kz$Lz$Mz$NBz$OBz$PBz$QBz$RBz$SBz$TBz$UBz$VBz$WBz$z$Bz$Cz$Kz$Lz$Mz$XBz$YBz$ZBz$z$Bz$Cz$Kz$Lz$Mz$kz$aBz$bBz$cBz$iz$JBz$z$Bz$Cz$Kz$Lz$Mz$kz$aBz$bBz$dBz$eBz$fBz$z$Bz$Cz$Kz$Lz$Mz$kz$aBz$gBz$hBz$iBz$QBz$BBz$z$Bz$Cz$Kz$Lz$Mz$kz$aBz$bBz$jBz$kBz$Iz$z$Bz$Cz$Kz$Lz$Mz$kz$aBz$bBz$jBz$lBz$mBz$nBz$z$Bz$Cz$Kz$Lz$Mz$kz$aBz$bBz$oBz$pBz$qBz$iz$JBz$z$Bz$Cz$Kz$Lz$Mz$kz$aBz$bBz$rBz$dBz$eBz$QBz$BBz$z$Bz$Cz$Kz$Lz$Mz$kz$aBz$sBz$tBz$bz$uBz$z$Bz$Cz$Kz$Lz$Mz$kz$aBz$sBz$vBz$wBz$xBz$z$Bz$Cz$Kz$Lz$Mz$kz$aBz$sBz$vBz$wBz$yBz$z$Bz$Cz$Kz$Lz$Mz$kz$aBz$sBz$ACz$BCz$CCz$z$Bz$Cz$Kz$Lz$Mz$kz$aBz$sBz$DCz$ECz$JBz$z$Bz$Cz$Kz$Lz$Mz$kz$aBz$FCz$GCz$HCz$ICz$JCz$z$Bz$Cz$Kz$Lz$Mz$kz$aBz$FCz$GCz$HCz$ICz$KCz$z$Bz$Cz$Kz$Lz$Mz$CBz$DBz$EBz$FBz$GBz$HBz$IBz$JBz$z$Bz$Cz$Kz$Lz$Mz$KBz$LBz$MBz$GBz$HBz$IBz$JBz$z$Bz$Cz$Kz$Lz$Mz$Sz$vz$wz$xz$yz$ABz$BBz$z$Bz$Cz$Kz$Lz$Mz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$LCz$z$Bz$Cz$Kz$Lz$Mz$MCz$NCz$OCz$z$Bz$Cz$Kz$Lz$Mz$PCz$QCz$RCz$SCz$TCz$UCz$z$Bz$Cz$Kz$Lz$VCz$WCz$XCz$YCz$ZCz$aCz$bCz$z$Bz$Cz$Kz$Lz$Mz$NBz$cCz$dCz$RCz$eCz$fCz$gCz$z$Bz$Cz$Kz$Lz$Mz$hCz$iCz$QBz$BBz$z$Bz$Cz$Kz$Lz$Mz$hCz$iCz$jCz$z$Bz$Cz$Kz$Lz$Mz$MCz$kCz$lCz$mCz$z$Bz$Cz$Kz$Lz$Mz$MCz$nCz$oCz$pCz$qCz$rCz$z$Bz$Cz$Kz$Lz$Mz$MCz$sCz$tCz$uCz$vCz$wCz$JBz$z$Bz$Cz$Kz$Lz$Mz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$cz$dz$ez$z$Bz$Cz$Kz$Lz$Mz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$xCz$yCz$ADz$BDz$CDz$z$Bz$Cz$Kz$Lz$Mz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$DDz$RCz$EDz$FDz$GDz$z$Bz$Cz$Kz$Lz$Mz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$HDz$IDz$az$bz$cz$dz$ez$z$Bz$Cz$Kz$Lz$Mz$MCz$JDz$KDz$LDz$MDz$NDz$ODz$LCz$z$Bz$Cz$Kz$Lz$VCz$PDz$QDz$RDz$lz$LCz$z$SDz$TDz$UDz$VDz$z$WDz$iz$XDz$YDz$ZDz$aDz$bDz$cDz$dDz$jz$z$Bz$Cz$Kz$Lz$VCz$eDz$QCz$fDz$gDz$hDz$iDz$jDz$z$Bz$Cz$Kz$Lz$VCz$kDz$lDz$mDz$nDz$oDz$z$Bz$Cz$Kz$Lz$VCz$kDz$lDz$mDz$pDz$qDz$rDz$z$Bz$Cz$Kz$Lz$Mz$Sz$Tz$Uz$SDz$sDz$tDz$uDz$iz$jz$z$Bz$Cz$Kz$Lz$Mz$XBz$vDz$wDz$xDz$yDz$iz$jz$z$Bz$Cz$Kz$Lz$Mz$AEz$BEz$CEz$DEz$yz$EEz$FEz$z$Bz$Cz$Kz$Lz$Mz$GEz$HEz$IEz$JEz$KEz$LEz$z$Bz$Cz$Kz$Lz$Mz$MEz$NEz$OEz$PEz$QEz$REz$SEz$iz$jz$z$Bz$Cz$Kz$Lz$Mz$KBz$TEz$UEz$VEz$WEz$QBz$XEz$z$Bz$Cz$Kz$Lz$YEz$ZEz$aEz$bEz$cEz$rDz$z$Bz$Cz$Kz$Lz$YEz$dEz$eEz$fEz$gEz$Tz$hEz$iEz$jEz$z$Bz$Cz$Kz$Lz$YEz$dEz$eEz$fEz$gEz$Tz$hEz$kEz$lEz$z$Bz$Cz$Kz$Lz$YEz$dEz$eEz$fEz$mEz$iz$jz$z$Bz$Cz$Kz$Lz$YEz$dEz$nEz$oEz$pEz$qEz$rEz$z$Bz$Cz$Kz$Lz$VCz$sEz$tEz$uEz$vEz$lEz$wEz$JBz$z$Bz$Cz$Kz$Lz$VCz$xEz$yEz$AFz$yz$z$Bz$Cz$Kz$Lz$VCz$xEz$mDz$nDz$oDz$z$Bz$Cz$Kz$Lz$VCz$BFz$CFz$DFz$EFz$uDz$iz$jz$z$Bz$Cz$Kz$Lz$VCz$BFz$CFz$DFz$EFz$FFz$GFz$HFz$IFz$JFz$jDz$z$Bz$Cz$Kz$Lz$VCz$KFz$LFz$MFz$NFz$z$Bz$Cz$Kz$Lz$VCz$WCz$nEz$YEz$OFz$PFz$QFz$z$qz$rz$sz$tz$RFz$z$Az$z$SFz$TFz$UFz$VFz$WFz$XFz$oEz$YFz$ZFz$aFz$bFz$z$cFz$z$dFz$z$cEz$eFz$z$fFz$gFz$hFz$iFz$jFz$kFz$lFz$mFz$nFz$oFz$pFz$qFz$rFz$sFz$tFz$uFz$z$SFz$TFz$vFz$wFz$xFz$yFz$AGz$BGz$CGz$DGz$EGz$FGz$z$GGz$HGz$IGz$JGz$KGz$LGz$MGz$NGz$OGz$PGz$QGz$RGz$z$GGz$HGz$IGz$JGz$SGz$TGz$UGz$PGz$QGz$RGz$z$GGz$HGz$IGz$JGz$SGz$VGz$WGz$XGz$YGz$ZGz$aGz$z$GGz$HGz$IGz$JGz$SGz$bGz$cGz$dGz$eGz$fGz$PGz$QGz$RGz$z$GGz$HGz$IGz$JGz$SGz$gGz$dCz$hGz$iGz$EGz$FGz$z$GGz$HGz$IGz$JGz$SGz$gGz$dCz$hGz$jGz$kGz$lGz$z$GGz$HGz$IGz$JGz$SGz$mGz$nGz$oGz$kGz$lGz$z$GGz$HGz$IGz$JGz$SGz$pGz$qGz$rGz$YGz$ZGz$aGz$z$GGz$HGz$IGz$JGz$SGz$sGz$tGz$uGz$vGz$wGz$xGz$z$cEz$yGz$z$dFz$z$AHz$z$qz$rz$sz$tz$RFz"

for step in "${STEPS[@]}"; do
    IFS=":" read -r text delay <<< "$step"
    print_step "$text" "$delay"
done

printf "\n[✔] Uninstallation completed successfully!\n\n\n"