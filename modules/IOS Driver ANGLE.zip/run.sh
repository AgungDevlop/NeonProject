#Pengatura. Perizinan 
pm grant com.android.angle android.permission.WRITE_SECURE_SETTINGS
pm > /dev/null 2>&1

# Memberikan izin akses penyimpanan
pm grant com.android.angle android.permission.READ_EXTERNAL_STORAGE > /dev/null 2>&1
pm grant com.android.angle android.permission.WRITE_EXTERNAL_STORAGE > /dev/null 2>&1
cmd package grant com.android.angle android.permission.READ_EXTERNAL_STORAGE > /dev/null 2>&1
cmd package grant com.android.angle android.permission.WRITE_EXTERNAL_STORAGE > /dev/null 2>&1

# Memberikan izin notifikasi
pm grant com.android.angle android.permission.POST_NOTIFICATIONS > /dev/null 2>&1
cmd package grant com.android.angle android.permission.POST_NOTIFICATIONS > /dev/null 2>&1

# Memberikan izin pengaturan sistem
pm grant com.android.angle android.permission.WRITE_SECURE_SETTINGS > /dev/null 2>&1
cmd package grant com.android.angle android.permission.WRITE_SECURE_SETTINGS > /dev/null 2>&1

# Mengizinkan aplikasi berjalan di latar belakang
cmd appops set com.android.angle RUN_IN_BACKGROUND allow > /dev/null 2>&1
cmd appops set com.android.angle RUN_ANY_IN_BACKGROUND allow > /dev/null 2>&1
cmd appops set com.android.angle START_FOREGROUND allow > /dev/null 2>&1

# Memberikan izin untuk wake lock (mencegah tidur)
cmd appops set com.android.angle WAKE_LOCK allow > /dev/null 2>&1

# Mengizinkan aplikasi mengelola penyimpanan
cmd appops set com.android.angle MANAGE_EXTERNAL_STORAGE allow > /dev/null 2>&1
cmd appops set com.android.angle LEGACY_STORAGE allow > /dev/null 2>&1

# Mengizinkan perubahan pengaturan sistem
cmd appops set com.android.angle WRITE_SETTINGS allow > /dev/null 2>&1

# Menolak izin akses statistik penggunaan (opsional, bisa dihapus jika tidak ingin dibatasi)
cmd appops set com.android.angle GET_USAGE_STATS deny > /dev/null 2>&1
(
#Peforma For Stability 
setprop debug.performance.tuning 1 
setprop debug.performance.profile 1 
setprop debug.performance.disturb false 
setprop debug.performance_schema_digests_size 9950000 
setprop debug.performance_schema 1 
setprop debug.performance_schema_max_memory_classes 387 
setprop debug.performance_schema_max_socket_classes 10 
) > /dev/null 2>&1 

#Angle Use
(
#New
setprop debug.angle.overlay FPS:Metal*PipelineCache*
setprop debug.hwui.shadow.renderer metal
setprop debug.renderengine.backend metal
setprop debug.stagefright.renderengine.backend metal
setprop debug.angle.backend metal
setprop debug.stagefright.renderengine.backend metal
setprop debug.angle.feature_overrides_enabled 1 preferLinearFilterForYUV:mapUnspecifiedColorSpaceToPassThrough
setprop debug.composition.type moltengl 
setprop debug.hwui.renderer moltengl
setprop debug.mediatek.composition.type moltengl
) > /dev/null 2>&1 

(
setprop debug.angle.enable_vulkan_api_dump_layer 1 
setprop debug.angle.validation 1 
setprop debug.gles.angle 1 
setprop debug.angle.capture.frame_end 200
setprop debug.angle.capture.enabled 1
setprop debug.angle.capture.out_dir foo
setprop debug.angle.capture.frame_start 0
setprop debug.angle.capture.label bar
setprop debug.angle.capture.trigger 20
setprop debug.gfx.angle.supported true
setprop debug.angle.rules /data/local/tmp/a4a_rules.json
settings put global graphics.egl angle
settings put global build_angle_deqp_tests true
settings put global proprietary_codecs true
setprop debug.angle_enable_vulkan true
setprop debug.angle_enable_vulkan_validation_layers true
setprop debug.angle_libs_suffix angle
setprop debug.angle_enable_null false
setprop debug.angle_force_thread_safety true
setprop debug.angle.markers 1
) > /dev/null 2>&1 

# Renderangle active
(
setprop debug.hwui.renderer moltengl
setprop debug.hwui.use_threaded_renderer true
settings put global angle_gl_driver_selection_value angle
settings put global angle_gl_driver_all_angle 1 ) > /dev/null 2>&1

(
#IOS DRVER PER APP  
settings put global angle_gl_driver_selection_values angle
settings put global angle_gl_driver_selection_package com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite
settings put global angle_allowlist com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite,com.netease.dfjssea,com.garena.game.df,com.hermes.p6gameos,com.pixonic.wwr
) > /dev/null 2>&1

#Angle Driver
(
settings put global angle_debug_package com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite,com.netease.dfjssea
settings put global angle_allowlist com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite,com.netease.dfjssea,com.garena.game.df,com.hermes.p6gameos,com.pixonic.wwr
 ) > /dev/null 2>&1

(
#Aktifkan Game Driver 
settings put global updatable_driver_production_opt_in_apps com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite,com.netease.dfjssea,com.garena.game.df,com.hermes.p6gameos,com.pixonic.wwr
settings put global updatable_driver_production_opt_out_apps 1
#Aktifkan Game Driver A11
settings put global game_driver_opt_in_apps com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite,com.netease.dfjssea,com.garena.game.df,com.hermes.p6gameos,com.pixonic.wwr
settings put global game_driver_opt_out_apps 1
) > /dev/null 2>&1

# Additional settings (optional, test for stability)
(
setprop debug.sf.use_frame_rate_priority 1
setprop debug.hw.vsync 0
setprop debug.sf.hwc.vsync_enqueue 0
setprop debug.generate-debug-info false
setprop debug.egl.traceGpuCompletion false
settings put system surface_flinger_use_frame_rate_api true ) > /dev/null 2>&1

# Optional vsync overrides (use with caution)
(
setprop debug.sf.hwc_disable_vsync 1
setprop debug.hwui.disable_vsync 1
 ) > /dev/null 2>&1

# Membuka aplikasi Angle
am start -a android.app.action.ANGLE_FOR_ANDROID_TOAST_MESSAGE -e open-app "Your Driver Game Angle" -n com.android.angle/.MainActivity > /dev/null 2>&1

cmd activity start -a android.app.action.ANGLE_FOR_ANDROID_TOAST_MESSAGE -e open-app "Your Driver Game Angle" -n com.android.angle/.MainActivity > /dev/null 2>&1