# Hentikan aplikasi sebelum dihapus
am force-stop com.android.angle > /dev/null 2>&1

# Hapus data aplikasi sebelum uninstall (opsional, jika ingin menghapus semua data)
pm clear com.android.angle > /dev/null 2>&1

# Uninstall aplikasi (untuk aplikasi yang diinstal oleh pengguna)
pm uninstall com.android.angle > /dev/null 2>&1

# Uninstall aplikasi (jika aplikasi merupakan bloatware/system app, membutuhkan akses root)
pm uninstall --user 0 com.android.angle > /dev/null 2>&1

(
#Peforma For Stability 
setprop debug.performance.tuning ""
setprop debug.performance.profile ""
setprop debug.performance.disturb ""
setprop debug.performance_schema_digests_size ""
setprop debug.performance_schema ""
setprop debug.performance_schema_max_memory_classes ""
setprop debug.performance_schema_max_socket_classes ""
#Angle Use
#New
setprop debug.angle.overlay FPS:Metal*PipelineCache*
setprop debug.renderengine.backend ""
setprop debug.stagefright.renderengine.backend ""
setprop debug.angle.backend ""
setprop debug.stagefright.renderengine.backend ""
setprop debug.angle.feature_overrides_enabled ""
setprop debug.composition.type ""
setprop debug.hwui.renderer ""
setprop debug.mediatek.composition.type""
setprop debug.angle.backend ""
setprop debug.angle.enable_vulkan_api_dump_layer ""
setprop debug.angle.validation ""
setprop debug.gles.angle ""
setprop debug.angle.overlay ""
setprop debug.angle.feature_overrides_enabled ""
setprop debug.angle.capture.frame_end ""
setprop debug.angle.capture.enabled ""
setprop debug.angle.capture.out_dir ""
setprop debug.angle.capture.frame_start ""
setprop debug.angle.capture.label ""
setprop debug.angle.capture.trigger ""
setprop debug.stagefright.renderengine.backend ""
setprop debug.hwui.shadow.renderer ""
setprop debug.renderengine.backend ""
setprop debug.composition.type ""
setprop debug.gfx.angle.supported ""
setprop debug.angle.rules ""
setprop debug.angle_enable_vulkan ""
setprop debug.angle_enable_vulkan_validation_layers ""
setprop debug.angle_libs_suffix ""
setprop debug.angle_enable_null ""
setprop debug.angle_force_thread_safety ""
setprop debug.angle.markers ""
settings put global graphics.egl ""
settings put global build_angle_deqp_tests ""
settings put global proprietary_codecs ""
) > /dev/null 2>&1

(
#IOS DRVER PER APP  
settings delete global angle_gl_driver_selection_values 
settings delete global angle_gl_driver_selection_package com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite
settings put global angle_allowlist com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,com.rockstargames.gtabycity,com.mojang.minecraftpe,com.levelinfinite.sgameGlobal,com.mobile.legends,com.mobilelegends.hwag,com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,net.kdt.pojavlaunch,com.mojang.minecraftpe,com.activision.callofduty.shooter,com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,com.pubg.krmobile,com.kurogame.wutheringwaves.global,com.craftsman.go,com.roblox.client,com.global.extremegames.arenabreakout,com.riotgames.league.wildrift,com.tencent.iglite
) > /dev/null 2>&1

# Uninstall Renderangle settings
(
setprop debug.hwui.renderer ""
setprop debug.hwui.use_threaded_renderer false
settings delete global angle_gl_driver_selection_value
settings delete global angle_gl_driver_all_angle
) > /dev/null 2>&1

# Uninstall Angle Driver settings
(
settings delete global angle_debug_package
settings delete global angle_allowlist
) > /dev/null 2>&1

# Uninstall Additional settings (optional, test for stability)
(
setprop debug.sf.use_frame_rate_priority 0
setprop debug.hw.vsync 1
setprop debug.sf.hwc.vsync_enqueue 1
setprop debug.generate-debug-info true
setprop debug.egl.traceGpuCompletion true
settings delete system surface_flinger_use_frame_rate_api
) > /dev/null 2>&1

# Uninstall Optional vsync overrides
(
setprop debug.sf.hwc_disable_vsync 0
setprop debug.hwui.disable_vsync 0
) > /dev/null 2>&1

#Delete Game Driver 
(
settings delete global updatable_driver_production_opt_in_apps
settings delete global updatable_driver_production_opt_out_apps 
settings delete global game_driver_opt_in_apps
settings delete global game_driver_opt_out_apps 
) > /dev/null 2>&1
