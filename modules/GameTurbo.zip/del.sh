echo ""
echo "█▓▒▒░░░ Restore System for Game Turbo Extreme ░░░▒▒▓█"
echo ""
sleep 1
echo "MODUL INI AKAN MENGEMBALIKAN SEMUA PENGATURAN KE KONDISI STANDAR"
echo "AUTOR: Agung Developer"
echo ""
sleep 1
echo "→ Menganalisis Pengaturan Saat Ini..."
sleep 0.5
echo "DEVICE: $(getprop ro.product.brand) $(getprop ro.product.model)"
echo "CPU_ABI: $(getprop ro.product.cpu.abi)"
echo "CURRENT_RENDERER: $(getprop debug.hwui.renderer)"
echo ""
echo "█▓▒▒░░░ MEMULAI PROSES PEMULIHAN SISTEM ░░░▒▒▓█"
echo ""
sleep 1

echo "→ [FASE 1/4] Mengaktifkan Kembali Manajemen Thermal..."
cmd thermalservice override-status -1 > /dev/null 2>&1
settings delete global thermal_throttling
(
setprop ctl.start thermald
setprop ctl.start thermal-engine
setprop ctl.start thermal_manager
setprop debug.thermal.cpu_thermal_throttle.disable 0
setprop debug.thermal.gpu_thermal_throttle.disable 0
setprop debug.thermal.gpu_core_clock_throttle.disable 0
setprop debug.thermal.gpu_shader_clock_throttle.disable 0
setprop debug.thermal.throttling.disable 0
setprop debug.thermal.auto_thermal_disable 0
setprop debug.thermal.zone.disabled 0
setprop debug.thermal.suspend.disabled 0
setprop debug.thermal.trip_point.disabled 0
setprop debug.thermal.thermal_policy.disable 0
setprop debug.thermal.balance_algorithm 1
setprop debug.thermal.performance_mode.disable 0
setprop debug.thermal.overheat_protection.disable 0
setprop debug.thermal.shutdown.disable 0
) > /dev/null 2>&1
sleep 0.5
echo "Manajemen Thermal Telah Dipulihkan."
echo ""

echo "→ [FASE 2/4] Mengembalikan Mode Daya & Sistem Inti ke Standar..."
cmd power set-fixed-performance-mode-enabled false > /dev/null 2>&1
cmd game mode standard global > /dev/null 2>&1
settings delete system bench_mark_mode
(
setprop debug.performance.tuning 0
setprop debug.power.throttling.disable 0
setprop persist.sys.performance.level 0
setprop logcat.live enable
) > /dev/null 2>&1
sleep 0.5
echo "Mode Daya & Sistem Inti Telah Dikembalikan."
echo ""

echo "→ [FASE 3/4] Mereset Tampilan, FPS & Mesin Render..."
settings delete system peak_refresh_rate
settings delete system min_refresh_rate
(
setprop debug.sf.set_fps ""
setprop debug.gralloc.max_fps ""
setprop debug.hwui.renderer skiagl
setprop ro.hwui.use_vulkan false
setprop debug.angle.backend ""
setprop debug.sf.hw 0
setprop debug.egl.hw 0
setprop persist.sys.ui.hw false
setprop debug.composition.type c2d
setprop debug.egl.swapinterval 1
) > /dev/null 2>&1
sleep 0.5
echo "Pengaturan Tampilan & Render Telah Direset."
echo ""

echo "→ [FASE 4/4] Membersihkan Properti Jaringan & Lainnya..."
(
setprop net.ipv4.tcp_fastopen 1
) > /dev/null 2>&1
sleep 0.5
echo "Properti Sistem Tambahan Telah Dibersihkan."
echo ""

sleep 1
echo "█▓▒▒░░░ PROSES PEMULIHAN AWAL TELAH SELESAI [✓] ░░░▒▒▓█"
echo ""
sleep 1
echo "‼️ PENTING SEKALI: REBOOT PERANGKAT ANDA SEKARANG JUGA! ‼️"
echo "Reboot adalah langkah terakhir untuk memastikan semua nilai kernel"
echo "dan properti sistem kembali 100% ke kondisi pabrikan."
echo ""
sleep 1
echo "SISTEM AKAN KEMBALI NORMAL SETELAH REBOOT."
echo ""
sleep 0.5
cmd notification post -S bigtext -t 'Restore System' 'Tag' 'PEMULIHAN SELESAI. Silakan REBOOT perangkat Anda sekarang. Autor Agung Developer.'