async function checkModuleExists(moduleName) {
    if (!window.Android || !window.Android.checkFileExists) return false;
    try {
        const fileName = moduleName.replace(/[^a-zA-Z0-9]/g, '') + ".sh",
            exists = await window.Android.checkFileExists(`/storage/emulated/0/Download/com.fps.injector/${fileName}`);
        (exists ? downloadedModules.add : downloadedModules.delete).call(downloadedModules, moduleName);
        localStorage.setItem("downloadedModules", JSON.stringify([...downloadedModules]));
        return exists;
    } catch (e) {
        return false;
    }
}

async function loadFpsModules() {
    allFpsModules = await loadData("cachedFpsModules", FPS_MODULES_URL, "fps-module-items");
    if (allFpsModules) {
        await Promise.all(allFpsModules.map(m => checkModuleExists(m.name)));
        renderFpsModules(allFpsModules);
    }
}

async function loadFakeDevices() {
    allFakeDevices = await loadData("cachedFakeDevices", FAKE_DEVICE_URL, "fake-device-items");
    if (allFakeDevices) {
        await Promise.all(allFakeDevices.map(d => checkModuleExists(d.name)));
        renderFakeDevices(allFakeDevices);
    }
}

async function loadCommands() {
    COMMANDS = await loadData("cachedCommands", COMMANDS_URL);
    RESTORE_COMMANDS = await loadData("cachedRestoreCommands", RESTORE_URL);
}

function renderFpsModules(modules) {
    const container = document.getElementById("fps-module-items");
    if (!container) return;
    container.innerHTML = "";
    modules.filter(m => m.name !== "Stop Module").forEach(module => {
        const item = document.createElement("div");
        item.className = "flex items-center justify-between hover:bg-white/[0.02] p-1 rounded-sm";
        item.innerHTML = `<label for="fps-${module.name.replace(/\s+/g, '-')}"><span class="text-[10px] font-bold text-gray-200 uppercase tracking-widest">${module.name}</span></label><label class="relative"><input type="checkbox" class="sr-only peer" id="fps-${module.name.replace(/\s+/g, '-')}" value="${module.name}" ${activeModules.has(module.name) ? 'checked' : ''}><div class="hw-switch"></div></label>`;
        container.appendChild(item);
    });
    
    container.addEventListener('change', (e) => {
        if (e.target.type === 'checkbox') {
            const selectedName = e.target.value;
            const isChecked = e.target.checked;
            const module = allFpsModules.find(m => m.name === selectedName);
            
            if (module) {
                if (isChecked) {
                    container.querySelectorAll('input[type="checkbox"]').forEach(cb => {
                        if (cb !== e.target) cb.checked = false;
                    });
                    allFpsModules.forEach(m => activeModules.delete(m.name));
                    activeModules.add(selectedName);
                    localStorage.setItem("activeModules", JSON.stringify([...activeModules]));
                    handleModuleAction(selectedName, module.url);
                } else {
                    activeModules.delete(selectedName);
                    localStorage.setItem("activeModules", JSON.stringify([...activeModules]));
                    const stopModule = allFpsModules.find(m => m.name === "Stop Module");
                    if (stopModule) handleModuleAction(stopModule.name, stopModule.url);
                }
            }
        }
    });
}

function renderFakeDevices(devices) {
    const container = document.getElementById("fake-device-items");
    if (!container) return;
    container.innerHTML = "";
    devices.filter(d => d.name !== "Restore Device").forEach(device => {
        const item = document.createElement("div");
        item.className = "flex items-center justify-between hover:bg-white/[0.02] p-1 rounded-sm";
        item.innerHTML = `<label for="device-${device.name.replace(/\s+/g, '-')}"><span class="text-[10px] font-bold text-gray-200 uppercase tracking-widest">${device.name}</span></label><label class="relative"><input type="checkbox" class="sr-only peer" id="device-${device.name.replace(/\s+/g, '-')}" value="${device.name}" ${activeFakeDevices.has(device.name) ? 'checked' : ''}><div class="hw-switch"></div></label>`;
        container.appendChild(item);
    });
    
    container.addEventListener('change', (e) => {
        if (e.target.type === 'checkbox') {
            const selectedName = e.target.value;
            const isChecked = e.target.checked;
            const device = allFakeDevices.find(d => d.name === selectedName);
            
            if (device) {
                if (isChecked) {
                    container.querySelectorAll('input[type="checkbox"]').forEach(cb => {
                        if (cb !== e.target) cb.checked = false;
                    });
                    activeFakeDevices.clear();
                    activeFakeDevices.add(selectedName);
                    localStorage.setItem("activeFakeDevices", JSON.stringify([...activeFakeDevices]));
                    handleFakeDeviceAction(selectedName, device.url);
                } else {
                    activeFakeDevices.delete(selectedName);
                    localStorage.setItem("activeFakeDevices", JSON.stringify([...activeFakeDevices]));
                    const restoreDevice = allFakeDevices.find(d => d.name === "Restore Device");
                    if (restoreDevice) handleFakeDeviceAction(restoreDevice.name, restoreDevice.url);
                }
            }
        }
    });
}

function handleModuleAction(moduleName, moduleUrl) {
    const fileName = moduleName.replace(/[^a-zA-Z0-9]/g, '') + ".sh";
    const modulePath = `/storage/emulated/0/Download/com.fps.injector/${fileName}`;
    if (!downloadedModules.has(moduleName)) {
        showDownloadModal(moduleName, moduleUrl);
        return;
    }
    let runCommand = `sh ${modulePath} && rm ${modulePath}`;
    if (selectedGames.size > 0 && !moduleName.includes("STOP")) {
        const packageNames = [...selectedGames].map(gameName => allGames.find(g => g.nama_game === gameName)?.nama_paket).filter(Boolean);
        if (packageNames.length > 0) {
            runCommand = `sh ${modulePath} ${packageNames.join(' ')} && rm ${modulePath}`;
        }
    }
    runCommandFlow(runCommand, moduleName);
}

function handleFakeDeviceAction(deviceName, deviceUrl) {
    const fileName = deviceName.replace(/[^a-zA-Z0-9]/g, '') + ".sh";
    const modulePath = `/storage/emulated/0/Download/com.fps.injector/${fileName}`;
    if (!downloadedModules.has(deviceName)) {
        showDownloadModal(deviceName, deviceUrl);
    } else {
        runCommandFlow(`sh ${modulePath} && rm ${modulePath}`, deviceName);
    }
}

async function handleRestore(moduleName, moduleUrl, stateSet, key, renderFunc, allData) {
    if (!(await checkShizukuStatus())) {
        getAlpine().showNotification("System simulated restoration.");
        return;
    }
    const fileName = moduleName.replace(/[^a-zA-Z0-9]/g, '') + ".sh";
    const modulePath = `/storage/emulated/0/Download/com.fps.injector/${fileName}`;
    const action = async () => {
        runCommandFlow(`sh ${modulePath} && rm ${modulePath}`, moduleName);
        stateSet.forEach(item => {
            if (allData.some(d => d.name === item)) stateSet.delete(item);
        });
        localStorage.setItem(key, JSON.stringify([...stateSet]));
        renderFunc(allData);
    };
    if (!downloadedModules.has(moduleName)) {
        showDownloadModal(moduleName, moduleUrl, action);
    } else { action(); }
}

function showDownloadModal(moduleName, moduleUrl, callback = null) {
    const alpine = getAlpine();
    alpine.activeModal = 'download';

    const progressCircle = document.getElementById("modal-progress-circle");
    const progressText = document.getElementById("modal-progress-text");
    const statusText = document.getElementById("modal-status");
    const title = document.getElementById("modal-title");

    title.innerHTML = `<i class="fas fa-download mr-2"></i>Downloading ${moduleName}`;
    statusText.textContent = "Starting...";
    
    const radius = progressCircle.r.baseVal.value;
    const circumference = 2 * Math.PI * radius;
    progressCircle.style.strokeDasharray = `${circumference} ${circumference}`;
    progressCircle.style.strokeDashoffset = circumference;
    progressText.textContent = "0%";
    
    window.downloadCallback = callback;
    let progress = 0;
    
    const interval = setInterval(() => {
        progress = Math.min(progress + 5, 90);
        const offset = circumference - (progress / 100) * circumference;
        progressCircle.style.strokeDashoffset = offset;
        progressText.textContent = `${progress}%`;
        statusText.textContent = `Progress: ${progress}%`;
    }, 200);

    window.downloadingModuleInterval = interval;
    
    try {
        if(window.Android && window.Android.downloadFile) {
            window.Android.downloadFile(moduleUrl, moduleName);
        } else {
            throw new Error("No Android context");
        }
    } catch (e) {
        clearInterval(interval);
        setTimeout(() => {
            getAlpine().showNotification("Mocked Download Success.");
            alpine.activeModal = '';
            if(window.downloadCallback) window.downloadCallback();
        }, 1500);
    }
}
